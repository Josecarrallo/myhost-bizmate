# 📋 ESPECIFICACIONES - Workflows 2, 3 y 4

**Fecha:** 22 Diciembre 2025  
**Estado:** Pendiente de construcción  
**Prioridad:** Alta - Completar el 23 Dic 2025

---

## WORKFLOW 2 — Owner Alert & Recommendation

### Objetivo
Generar recomendaciones SOLO cuando hay señales de alerta (baja ocupación, gaps, cancelaciones).

### Trigger
Se dispara al final del Workflow 1 si:
- `occupancy_next_7d < 0.55` OR
- `cancellations_last_7d >= 2` OR
- existe `alert.severity = medium/high`

**Implementación sugerida:** 
- Añadir nodo IF al final del Workflow 1
- Si condición se cumple → llamar Workflow 2 via HTTP Request

### Input
Reutilizar el objeto del Workflow 1. NO recalcular todo.

### Proceso IA
Usar Claude API para generar:
1. **3 hipótesis** del "por qué" (causas posibles)
2. **3 acciones concretas** (quick wins)
3. **1 acción condicional** ("solo si...")
4. **1 pregunta para el owner** (para mejorar contexto futuro)

### Persistencia
**Tabla:** `owner_recommendations`
```sql
CREATE TABLE owner_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  date date NOT NULL,
  recommendation_text text,
  actions_json jsonb,
  created_at timestamptz DEFAULT now()
);
```

### Output
Enviar por WhatsApp al owner.

### Estructura del Workflow
```
Webhook (desde WF1) → Format Input → Claude API (recomendaciones) → Format Output → Save to Supabase → Send WhatsApp
```

---

## WORKFLOW 3 — Owner Ask MyHost (Chat Interno)

### Objetivo
Chat interno del owner con:
- Datos en vivo (Supabase)
- Memoria (últimos insights + recommendations)
- Estilo "co-manager" (no chatbot genérico)

### Trigger
Webhook/WhatsApp inbound
- Input: `tenant_id` + `owner_phone` + `message_text`

### Retrieval (Contexto)
1. Traer últimos 7 `owner_insights`
2. Traer últimos 7 `owner_recommendations`
3. Si pregunta requiere datos en vivo → consultar Supabase

### Proceso IA
**Reglas:**
- Nunca inventar datos
- Citar cifras concretas si existen
- Si falta un dato, pedir 1 sola aclaración
- Responder como co-manager profesional

### Persistencia
**Tabla:** `owner_conversations`
```sql
CREATE TABLE owner_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  timestamp timestamptz DEFAULT now(),
  question text NOT NULL,
  answer text NOT NULL,
  sources_json jsonb
);
```

### Output
Responder por WhatsApp.

### Estructura del Workflow
```
Webhook (inbound) → Get Context (insights + recommendations) → Get Live Data (si necesario) → Claude API (respuesta) → Save Conversation → Send WhatsApp
```

### Ejemplos de Preguntas
- "¿Cuántos check-ins tengo mañana?"
- "¿Cómo va la ocupación este mes?"
- "¿Qué recomendaciones me diste ayer?"
- "¿Cuál es mi revenue de la semana?"

---

## WORKFLOW 4 — Owner AI Assistant (Executive Summary)

### Objetivo
Generar un Executive Summary completo bajo demanda, más detallado que el Daily Intelligence.

### Trigger
Webhook POST con:
- `tenant_id`
- `period` (opcional: "week", "month", "quarter")
- `property_id` (opcional: filtrar por propiedad)

### Datos a Incluir
1. **Resumen del período**
   - Total bookings
   - Total revenue
   - Ocupación promedio
   - Comparativa con período anterior

2. **Top performers**
   - Propiedad más rentable
   - Mejor mes/semana
   - Huésped más frecuente

3. **Análisis de tendencias**
   - Tendencia de ocupación
   - Estacionalidad
   - Fuentes de reserva

4. **Recomendaciones estratégicas**
   - Oportunidades detectadas
   - Riesgos identificados
   - Acciones sugeridas

### Formato de Output
Documento más extenso (puede ser 1000+ caracteres), enviado por:
- WhatsApp (resumen)
- Email (versión completa)

### Estructura del Workflow
```
Webhook → Get All Data (período) → Calculate Metrics → Claude API (executive summary) → Format Report → Send WhatsApp + Send Email
```

---

## TABLAS SQL A CREAR

```sql
-- Tabla para Workflow 2
CREATE TABLE owner_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  date date NOT NULL,
  trigger_reason text,
  recommendation_text text,
  actions_json jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_owner_recommendations_tenant_date ON owner_recommendations(tenant_id, date);

-- Tabla para Workflow 3
CREATE TABLE owner_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  timestamp timestamptz DEFAULT now(),
  question text NOT NULL,
  answer text NOT NULL,
  sources_json jsonb,
  context_used jsonb
);

CREATE INDEX idx_owner_conversations_tenant ON owner_conversations(tenant_id);
CREATE INDEX idx_owner_conversations_timestamp ON owner_conversations(timestamp DESC);
```

---

## PRIORIDAD DE IMPLEMENTACIÓN

| Orden | Workflow | Complejidad | Dependencias |
|-------|----------|-------------|--------------|
| 1 | WF2 - Alert & Recommendation | Media | WF1 completado |
| 2 | WF3 - Ask MyHost | Alta | Tablas creadas |
| 3 | WF4 - Executive Summary | Media | Ninguna |

---

## NOTAS DE IMPLEMENTACIÓN

### Para Workflow 2
- Modificar WF1 para añadir nodo IF al final
- Si hay alertas → trigger WF2
- Pasar payload completo de WF1 a WF2

### Para Workflow 3
- Necesita manejar WhatsApp inbound (webhook de ChakraHQ)
- Implementar sistema de memoria simple
- Detectar si pregunta necesita datos en vivo

### Para Workflow 4
- Puede ser standalone
- Considerar límites de tokens de Claude para reportes largos
- Posiblemente dividir en múltiples llamadas a la API

---

**Documento creado:** 22 Diciembre 2025  
**Para implementar:** 23 Diciembre 2025  
**Autor:** Claude AI
