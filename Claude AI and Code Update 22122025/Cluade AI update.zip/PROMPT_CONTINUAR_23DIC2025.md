# 🤖 PROMPT PARA CONTINUAR - 23 Diciembre 2025

**Copiar y pegar este prompt completo en Claude AI para continuar el trabajo**

---

```
Hola Claude! Continuamos con el proyecto MY HOST BizMate - workflows de n8n.

## CONTEXTO DEL PROYECTO

MY HOST BizMate es una plataforma de gestión de propiedades vacacionales con:
- **Frontend:** React + Vite + Supabase
- **Backend:** Supabase (PostgreSQL + Auth)
- **Automatización:** n8n workflows
- **n8n URL:** https://n8n-production-bb2d.up.railway.app

## ESTADO ACTUAL (22 Dic 2025)

### ✅ COMPLETADO - Workflow 1: Owner Daily Intelligence
- **ID:** aergpRINvoJEyufR
- **Estado:** ACTIVO, funcionando
- **Trigger:** Schedule 9AM + Webhook + Manual
- **Función:** Genera resumen diario de KPIs y envía por WhatsApp
- **Probado:** 3 escenarios exitosos

### ⏳ PENDIENTE - Workflows a construir hoy:

**Workflow 2 - Owner Alert & Recommendation**
- Se dispara al final del Workflow 1 si:
  - occupancy_next_7d < 0.55 OR
  - cancellations_last_7d >= 2 OR
  - existe alert severity medium/high
- Genera 3 hipótesis, 3 acciones, 1 pregunta al owner
- Guarda en tabla owner_recommendations
- Envía por WhatsApp

**Workflow 3 - Owner Ask MyHost (Chat interno)**
- Webhook/WhatsApp inbound
- Consulta datos en vivo de Supabase
- Memoria: últimos 7 owner_insights + owner_recommendations
- Responde como "co-manager"
- Guarda en owner_conversations

**Workflow 4 - Owner AI Assistant (Executive Summary)**
- Webhook bajo demanda
- Genera executive summary completo
- Más detallado que el daily intelligence

## CREDENCIALES ACTIVAS

- **Supabase ID:** SJLQzwU9BVHEVAGc
- **ChakraHQ WhatsApp:** Phone ID 944855278702577, Bearer token configurado
- **Anthropic API:** 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
- **Owner phone:** 34619794604
- **Owner email:** josecarrallodelafuente@gmail.com
- **tenant_id:** 00000000-0000-0000-0000-000000000000

## TABLAS EN SUPABASE

Existentes:
- bookings (id, property_id, guest_name, guest_email, check_in, check_out, status, total_price, etc.)
- properties
- owner_insights (id, tenant_id, date, payload_json, summary_text, created_at)

Por crear:
- owner_recommendations (id, tenant_id, date, recommendation_text, actions_json, created_at)
- owner_conversations (tenant_id, timestamp, question, answer, sources_json)

## REGLAS IMPORTANTES

1. **NUNCA improvises.** Sigue las especificaciones del documento.
2. **ANTES de ejecutar cualquier acción:** Muéstrame el plan completo y espera mi aprobación ("GO").
3. **Si algo no funciona:** PARA, explica qué falló, propón alternativas.
4. **NO tomes decisiones unilaterales.** Yo decido, tú ejecutas.
5. **Dame JSONs completos** que pueda importar directamente en n8n.
6. **Prueba mental:** Antes de darme código, verifica que la sintaxis es correcta.

## ESTRUCTURA DE WORKFLOW QUE FUNCIONA

El Workflow 1 que funciona tiene esta estructura:
```
Trigger → Supabase (query) → Code (JavaScript) → HTTP Request (Claude API) → Set (format) → Supabase (save) → HTTP Request (WhatsApp)
```

Usar esta misma estructura lineal para los nuevos workflows.

## LO QUE NECESITO HOY

1. Construir Workflow 2 - Owner Alert & Recommendation
2. Construir Workflow 3 - Owner Ask MyHost
3. Construir Workflow 4 - Owner AI Assistant
4. Probar todos los workflows
5. Actualizar documentación

## ARCHIVOS DE REFERENCIA

El documento original con especificaciones está en:
- PROMPT_PARA_CLAUDE_AI_N8N.md

¿Empezamos con Workflow 2?
```

---

## NOTAS ADICIONALES PARA CLAUDE

### Lecciones aprendidas de la sesión del 22 Dic:

1. **No usar concatenación con `+` en JSON body de n8n** - Usar template literals `{{ $json.field }}`

2. **Siempre activar "Always Output Data"** en nodos Supabase que pueden devolver vacío

3. **Para probar workflows manualmente:**
   - Añadir nodo "Manual Trigger" conectado al flujo
   - O usar webhook con PowerShell: `Invoke-RestMethod -Method POST -Uri "URL"`

4. **tenant_id debe ser UUID válido**, no string "default"

5. **Estructura lineal funciona mejor** que paralelo con múltiples nodos Supabase

6. **API keys pueden expirar** - verificar si hay error de autenticación

### Comandos útiles PowerShell:
```powershell
# Ejecutar webhook
Invoke-RestMethod -Method POST -Uri "https://n8n-production-bb2d.up.railway.app/webhook/owner-daily-intelligence"
```

### SQL útiles:
```sql
-- Ver registros de owner_insights
SELECT * FROM owner_insights ORDER BY created_at DESC;

-- Limpiar registros de prueba
DELETE FROM owner_insights WHERE date = '2025-12-22';

-- Limpiar bookings de prueba
DELETE FROM bookings WHERE guest_email LIKE '%@test.com';
```
