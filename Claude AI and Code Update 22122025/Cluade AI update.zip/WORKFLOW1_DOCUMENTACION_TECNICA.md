# 📚 DOCUMENTACIÓN TÉCNICA - Workflow 1: Owner Daily Intelligence

**Versión:** 1.0  
**Fecha:** 22 Diciembre 2025  
**Estado:** ✅ Producción  
**ID n8n:** aergpRINvoJEyufR

---

## 1. DESCRIPCIÓN GENERAL

El Workflow 1 "Owner Daily Intelligence" genera un resumen diario automático del negocio para el propietario, incluyendo KPIs, eventos del día, alertas y perspectivas futuras. El resumen se guarda en base de datos y se envía por WhatsApp.

---

## 2. TRIGGERS (3 modos de ejecución)

### 2.1 Schedule Trigger (Automático)
- **Hora:** 9:00 AM diario
- **Timezone:** Asia/Singapore
- **Estado:** Activo

### 2.2 Manual Trigger (Pruebas)
- Click en "Execute workflow" en n8n
- Para testing durante desarrollo

### 2.3 Webhook (Externo)
- **URL:** `https://n8n-production-bb2d.up.railway.app/webhook/owner-daily-intelligence`
- **Método:** POST
- **Uso:** Integración con otros sistemas

---

## 3. FLUJO DE DATOS

```
┌─────────────────────┐
│  Schedule/Manual/   │
│      Webhook        │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Get All Bookings  │  ← Supabase: SELECT * FROM bookings
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Calculate KPIs    │  ← JavaScript: Filtra y calcula métricas
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Generate WhatsApp   │  ← Claude API: Genera texto resumen
│       Text          │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Format Output     │  ← Prepara JSON para guardar
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Save to Owner       │  ← Supabase: INSERT owner_insights
│     Insights        │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Send WhatsApp       │  ← ChakraHQ API: Envía mensaje
│     Summary         │
└─────────────────────┘
```

---

## 4. DETALLE DE NODOS

### 4.1 Get All Bookings
- **Tipo:** Supabase
- **Operación:** Get Many
- **Tabla:** bookings
- **Filtro:** Ninguno (trae todos)
- **Return All:** ON

### 4.2 Calculate KPIs
- **Tipo:** Code (JavaScript)
- **Modo:** Run Once for All Items

**Métricas calculadas:**
| Métrica | Descripción | Cálculo |
|---------|-------------|---------|
| checkins_today | Check-ins hoy | bookings.filter(check_in === today) |
| checkouts_today | Check-outs hoy | bookings.filter(check_out === today) |
| in_house | Huéspedes actuales | check_in <= today < check_out, status=confirmed |
| revenue_next_7d | Ingresos próx 7d | SUM(total_price) próximos 7 días |
| occupancy_next_7d | Ocupación próx 7d | bookings_7d / 7 (máx 1.0) |
| cancellations_last_7d | Cancelaciones 7d | status=cancelled, updated_at >= 7 días atrás |

**Alertas generadas:**
- Ocupación < 55%: severity "medium"
- Cancelaciones >= 2: severity "medium"

**Output JSON:**
```json
{
  "tenant_id": "00000000-0000-0000-0000-000000000000",
  "date": "2025-12-22",
  "owner_phone": "34619794604",
  "owner_email": "josecarrallodelafuente@gmail.com",
  "kpis": {
    "checkins_today": 0,
    "checkouts_today": 0,
    "in_house": 0,
    "occupancy_next_7d": 0.0,
    "revenue_next_7d": 0,
    "cancellations_last_7d": 0
  },
  "events": [],
  "alerts": [],
  "outlook": {
    "next_7d_bookings": 0,
    "next_30d_bookings": 0
  }
}
```

### 4.3 Generate WhatsApp Text
- **Tipo:** HTTP Request
- **URL:** https://api.anthropic.com/v1/messages
- **Método:** POST
- **Modelo:** claude-sonnet-4-20250514
- **Max tokens:** 500

**Headers:**
- x-api-key: [API KEY]
- anthropic-version: 2023-06-01
- content-type: application/json

**Prompt:**
```
Genera un resumen diario breve para WhatsApp en español. 
Datos: tenant_id, date, checkins, checkouts, in_house, occupancy, revenue, cancellations, outlook_7d, outlook_30d. 
Formato: Saludo con fecha, 3 bullets KPIs, alertas si hay, 1 acción. 
Max 400 chars. Usa emojis.
```

### 4.4 Format Output
- **Tipo:** Set
- **Modo:** Raw JSON
- Combina datos de Calculate KPIs con texto de Claude

### 4.5 Save to Owner Insights
- **Tipo:** Supabase
- **Operación:** Create
- **Tabla:** owner_insights

**Campos:**
- tenant_id
- date
- payload_json
- summary_text

### 4.6 Send WhatsApp Summary
- **Tipo:** HTTP Request
- **URL:** https://api.chakrahq.com/v1/ext/plugin/whatsapp/.../messages
- **Método:** POST

**Body:**
```json
{
  "messaging_product": "whatsapp",
  "to": "34619794604",
  "type": "text",
  "text": {
    "body": "[mensaje generado]"
  }
}
```

---

## 5. TABLA SUPABASE: owner_insights

```sql
CREATE TABLE owner_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  date date NOT NULL,
  payload_json jsonb NOT NULL,
  summary_text text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_owner_insights_tenant_date ON owner_insights(tenant_id, date);
```

---

## 6. EJEMPLOS DE MENSAJES GENERADOS

### Escenario: Baja ocupación
```
📅 **Resumen 22/12/2025**
🏨 Ocupación: 29% (2 huéspedes)
💰 Ingresos: €1,925
📋 Sin check-ins/check-outs hoy
🔍 **Próximos días:**
• 7 días: 2 reservas
• 30 días: 8 reservas
⚠️ **Alerta**: Ocupación baja para temporada navideña
🎯 **Acción**: Revisar estrategia de precios
```

### Escenario: Alta ocupación
```
📅 **Resumen 22 Dic 2025**
• 🏨 Ocupación: 100% (4 huéspedes)
• 💰 Ingresos: $5,875
• 📊 Reservas: 8 próximos 7d, 14 próximos 30d
✅ Sin alertas - Operación normal
🎯 **Acción**: Revisar disponibilidad para maximizar ingresos
```

---

## 7. TROUBLESHOOTING

### Error: "JSON parameter needs to be valid JSON"
- **Causa:** Concatenación con `+` en JSON body
- **Solución:** Usar template literals `{{ $json.field }}`

### Error: "duplicate key value violates unique constraint"
- **Causa:** Ya existe registro para esa fecha
- **Solución:** Se eliminó el índice único; ahora permite múltiples registros

### Error: "invalid x-api-key"
- **Causa:** API key expirada o incorrecta
- **Solución:** Generar nueva key en console.anthropic.com

### Error: "Node hasn't been executed"
- **Causa:** Nodos en paralelo no ejecutados
- **Solución:** Usar estructura lineal, un nodo tras otro

---

## 8. MANTENIMIENTO

### Limpieza de registros antiguos
```sql
DELETE FROM owner_insights WHERE created_at < NOW() - INTERVAL '90 days';
```

### Verificar última ejecución
```sql
SELECT * FROM owner_insights ORDER BY created_at DESC LIMIT 1;
```

---

## 9. CÓDIGO COMPLETO: Calculate KPIs

```javascript
// Configuración
const today = new Date().toISOString().split('T')[0];
const todayDate = new Date(today);

// Fechas de referencia
const next7Days = new Date(todayDate);
next7Days.setDate(next7Days.getDate() + 7);
const next7DaysStr = next7Days.toISOString().split('T')[0];

const next30Days = new Date(todayDate);
next30Days.setDate(next30Days.getDate() + 30);
const next30DaysStr = next30Days.toISOString().split('T')[0];

const last7Days = new Date(todayDate);
last7Days.setDate(last7Days.getDate() - 7);
const last7DaysStr = last7Days.toISOString().split('T')[0];

// Obtener todos los bookings
const allBookings = $input.all().map(item => item.json);

// Filtrar por métricas
const checkinsToday = allBookings.filter(b => b.check_in === today);
const checkoutsToday = allBookings.filter(b => b.check_out === today);
const inHouse = allBookings.filter(b => 
  b.check_in <= today && 
  b.check_out > today && 
  b.status === 'confirmed'
);

// Próximos 7 días
const next7DaysBookings = allBookings.filter(b => 
  b.check_in >= today && 
  b.check_in <= next7DaysStr && 
  b.status === 'confirmed'
);

// Próximos 30 días
const next30DaysBookings = allBookings.filter(b => 
  b.check_in >= today && 
  b.check_in <= next30DaysStr && 
  b.status === 'confirmed'
);

// Cancelaciones últimos 7 días
const cancellationsLast7d = allBookings.filter(b => 
  b.status === 'cancelled' && 
  b.updated_at && 
  b.updated_at.split('T')[0] >= last7DaysStr
);

// Calcular KPIs
const checkins_today = checkinsToday.length;
const checkouts_today = checkoutsToday.length;
const in_house = inHouse.length;
const cancellations_last_7d = cancellationsLast7d.length;

// Revenue próximos 7 días
const revenue_next_7d = next7DaysBookings.reduce((sum, b) => {
  return sum + (parseFloat(b.total_price) || 0);
}, 0);

// Ocupación próximos 7 días (heurística simple)
const occupancy_next_7d = Math.min(next7DaysBookings.length / 7, 1.0);

// Eventos de hoy
const events = [];
checkinsToday.forEach(b => {
  events.push({
    type: 'checkin',
    guest: b.guest_name || 'Guest',
    property_id: b.property_id
  });
});
checkoutsToday.forEach(b => {
  events.push({
    type: 'checkout',
    guest: b.guest_name || 'Guest',
    property_id: b.property_id
  });
});

// Alertas
const alerts = [];
if (occupancy_next_7d < 0.55) {
  alerts.push({
    severity: 'medium',
    message: 'Ocupación baja próximos 7 días: ' + Math.round(occupancy_next_7d * 100) + '%'
  });
}
if (cancellations_last_7d >= 2) {
  alerts.push({
    severity: 'medium',
    message: cancellations_last_7d + ' cancelaciones en últimos 7 días'
  });
}

// Output estructurado
const output = {
  tenant_id: '00000000-0000-0000-0000-000000000000',
  date: today,
  owner_phone: '34619794604',
  owner_email: 'josecarrallodelafuente@gmail.com',
  kpis: {
    checkins_today,
    checkouts_today,
    in_house,
    occupancy_next_7d: Math.round(occupancy_next_7d * 100) / 100,
    revenue_next_7d,
    cancellations_last_7d
  },
  events,
  alerts,
  outlook: {
    next_7d_bookings: next7DaysBookings.length,
    next_30d_bookings: next30DaysBookings.length
  }
};

return [{ json: output }];
```

---

**Documento creado:** 22 Diciembre 2025  
**Autor:** Claude AI  
**Proyecto:** MY HOST BizMate
