import { Hero } from "@/components/hero"
import { VillaGallery } from "@/components/villa-gallery"
import { Experience } from "@/components/experience"
import { ContactForm } from "@/components/contact-form"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <VillaGallery />
      <Experience />
      <ContactForm />
      <Footer />
    </main>
  )
}
