# PROMPT DE RECUPERACIÓN - MY HOST BizMate
## Última actualización: 19 Diciembre 2024

---

## CÓMO USAR ESTE PROMPT

Copia y pega el siguiente texto al iniciar una nueva conversación con Claude para continuar el trabajo en el proyecto MY HOST BizMate:

---

## PROMPT DE RECUPERACIÓN

```
Soy José Carrallo, fundador de MY HOST BizMate, una plataforma SaaS de automatización WhatsApp con IA para hoteles boutique en Bali/Indonesia.

PROYECTO ACTUAL: Sistema de reservas para Izumi Hotel (hotel boutique 5 estrellas en Ubud, Bali, apertura verano 2026)

ARQUITECTURA:
- n8n en Railway (workflows de automatización)
- ChakraHQ (WhatsApp Business API con coexistencia)
- Supabase (base de datos PostgreSQL)
- OpenAI GPT-4.1-mini (AI Agent)
- Vapi.ai (asistente de voz web)

WORKFLOWS ACTIVOS:
1. Workflow VII (F8YPuLhcNe6wGcCv) - Staff Notification: Notifica al staff y confirma al huésped cuando hay nueva reserva
2. Workflow VIII (ln2myAS3406D6F8W) - WhatsApp AI Agent: Agente multimodal (texto, audio, imágenes) para atención al cliente
3. Workflow IX (3sU4RgV892az8nLZ) - Vapi Voice: Backend para asistente de voz en la web

FUNCIONALIDADES COMPLETADAS:
✅ Chatbot WhatsApp multimodal (texto, audio, imágenes)
✅ Verificación de disponibilidad en tiempo real
✅ Cálculo de precios automático
✅ Creación de reservas con precio correcto
✅ Notificaciones automáticas al staff
✅ Confirmación automática al huésped con info de contacto
✅ Asistente de voz web (Vapi)
✅ Respuesta audio-a-audio en WhatsApp

DATOS IMPORTANTES:
- Supabase URL: https://jjpscimtxrudtepzwhag.supabase.co
- Property ID Izumi: 18711359-1378-4d12-9ea6-fb31c0b1bac2
- WhatsApp Izumi: +62 813 2576 4867
- n8n: https://n8n-production-bb2d.up.railway.app

LECCIONES APRENDIDAS:
1. Los prompts del AI Agent deben ser SIMPLES y DIRECTOS
2. Instrucción clave: "SIEMPRE usa Calculate Price PRIMERO, luego pasa ese precio EXACTO a Create Booking"
3. Añadir regla: "Nunca uses comillas dobles en tus respuestas"
4. El nodo Create Booking necesita: {{ $fromAI('total_price', 'precio total en dólares como número entero sin símbolo') }}

PROBLEMA COMÚN - WhatsApp no envía:
Si los mensajes se quedan con reloj, borrar chat completo, forzar cierre de WhatsApp, esperar 10 seg, reabrir.

¿En qué puedo ayudarte hoy?
```

---

## VERSIÓN CORTA (para contexto rápido)

```
Proyecto MY HOST BizMate - Izumi Hotel Bali

Workflows n8n:
- VII (F8YPuLhcNe6wGcCv): Staff Notification
- VIII (ln2myAS3406D6F8W): WhatsApp AI Agent
- IX (3sU4RgV892az8nLZ): Vapi Voice

Stack: n8n + ChakraHQ + Supabase + OpenAI + Vapi

El sistema permite reservas vía WhatsApp y voz con AI.
```

---

## CONTACTOS

- **José (Fundador):** +34 619 794 604
- **Izumi Hotel:** +62 813 2576 4867
- **Web:** www.my-host-bizmate.com
