# GUÍA RÁPIDA DE TROUBLESHOOTING
## MY HOST BizMate - Izumi Hotel
## Última actualización: 19 Diciembre 2024

---

# PROBLEMAS COMUNES Y SOLUCIONES

---

## 1. PRECIO $0 EN RESERVAS

### Síntoma
La reserva se crea pero el precio aparece como $0

### Causa
El AI Agent no está usando Calculate Price antes de Create Booking

### Solución
1. Verificar que el nodo **Create Booking** tenga:
```
"total_price": {{ $fromAI('total_price', 'precio total en dólares como número entero sin símbolo, ejemplo 1120') }},
```

2. Verificar que el **System Message** del AI Agent incluya:
```
4. SIEMPRE usa Calculate Price PRIMERO y dile el precio al usuario
6. Al crear reserva, pasa el precio EXACTO de Calculate Price como total_price
```

3. Usar el prompt SIMPLE (no el largo con muchas secciones)

---

## 2. MENSAJES WHATSAPP NO SE ENVÍAN (RELOJ)

### Síntoma
Los mensajes se quedan con el icono de reloj y nunca se envían

### Causa
Cache corrupto en WhatsApp

### Solución Paso a Paso
1. **Borrar mensajes pendientes** - Mantener pulsado → Eliminar para mí
2. **Borrar chat completo** - Mantener pulsado sobre el chat → Eliminar
3. **Forzar cierre de WhatsApp:**
   - Android: Ajustes → Apps → WhatsApp → Forzar detención
   - iPhone: Deslizar hacia arriba para cerrar
4. **Esperar 10 segundos**
5. **Reabrir WhatsApp**
6. **Crear nuevo chat** con el número y enviar "Hola"

---

## 3. SESIÓN DE 24 HORAS EXPIRADA

### Síntoma
Mensaje en ChakraHQ: "WhatsApp 24 Hour Limit" / "WhatsApp session ended"

### Causa
WhatsApp Business API solo permite mensajes durante 24h después del último mensaje del cliente

### Solución
El **cliente debe enviar un mensaje primero** para abrir nueva ventana de 24 horas

Para mensajes después de 24h, se necesitan **Message Templates** aprobados por Meta (requiere plan de pago en ChakraHQ)

---

## 4. WORKFLOW NO SE EJECUTA

### Síntoma
Envías mensaje pero no aparece ejecución en n8n

### Verificaciones
1. **¿Workflow está ACTIVE?** - Verificar toggle verde en n8n
2. **¿Webhook correcto en ChakraHQ?** 
   - Workflow VIII: `https://n8n-production-bb2d.up.railway.app/webhook/894ed1af-89a5-44c9-a340-6e571eacbd53`
3. **¿ChakraHQ está CONNECTED?** - Verificar en WhatsApp Setup
4. **¿Es mensaje o status?** - El Filter solo deja pasar mensajes reales, no notificaciones de status

---

## 5. ERROR JSON EN RESPUESTAS

### Síntoma
Error: "Invalid JSON" en nodos de respuesta

### Causa
El AI Agent incluye comillas dobles `"` o saltos de línea `\n` en sus respuestas

### Solución
1. Añadir regla en el prompt: `7. Nunca uses comillas dobles en tus respuestas`

2. Para Workflow IX (Vapi), añadir nodo **Code** entre AI Agent y Respond to Vapi:
```javascript
const toolCallId = $('Keep Session id & Query').first().json.id;
const rawOutput = $('AI Agent').first().json.output;

let cleanOutput = String(rawOutput)
  .replace(/\\/g, '\\\\')
  .replace(/"/g, '\\"')
  .replace(/\n/g, ' ')
  .replace(/\r/g, '')
  .replace(/\t/g, ' ');

return [{
  json: {
    toolCallId: toolCallId,
    result: cleanOutput
  }
}];
```

---

## 6. AI AGENT NO USA LAS HERRAMIENTAS

### Síntoma
El agente responde pero no consulta disponibilidad ni calcula precios

### Causa
Prompt demasiado largo o instrucciones confusas

### Solución
1. Usar el prompt SIMPLE y DIRECTO
2. Las instrucciones de herramientas deben ser explícitas:
```
HERRAMIENTAS - ÚSALAS:
- Check Availability: Cuando pregunten disponibilidad...
- Calculate Price: Para calcular precio total...
- Create Booking: SOLO después de Calculate Price...
```

---

## 7. AUDIO NO SE PROCESA

### Síntoma
Los mensajes de audio no generan respuesta

### Verificaciones
1. **¿Switch tiene rama Audio?** - Verificar que existe la condición para audio
2. **¿Download audio funciona?** - Verificar URL de ChakraHQ
3. **¿Transcribe funciona?** - Verificar credenciales OpenAI
4. **¿mimeType correcto?** - El nodo "Fix mimeType for Audio" debe cambiar `audio/mp3` a `audio/mpeg`

---

## 8. IMAGEN NO SE ANALIZA

### Síntoma
Las imágenes no generan respuesta o respuesta incorrecta

### Verificaciones
1. **¿Download Image funciona?** - Verificar URL de ChakraHQ
2. **¿Analyze image tiene modelo correcto?** - Debe ser `gpt-4o-mini`
3. **¿inputType es base64?** - Verificar configuración del nodo

---

# CONTACTOS DE SOPORTE

| Servicio | Soporte |
|----------|---------|
| ChakraHQ | support@chakrahq.com |
| n8n | community.n8n.io |
| Supabase | supabase.com/support |
| Vapi | docs.vapi.ai |

---

# LOGS Y DEBUGGING

## Ver logs en n8n
1. Ir al workflow
2. Click en "Executions"
3. Seleccionar ejecución con error
4. Click en nodo rojo para ver detalle del error

## Ver logs en Railway
1. Ir a dashboard.railway.app
2. Seleccionar proyecto n8n
3. Click en "Logs"

---

*Documento actualizado: 19 Diciembre 2024*
