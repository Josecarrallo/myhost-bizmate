# PROMPT DE CONTINUACIÓN - MY HOST BizMate
## Fecha: 16 Enero 2026
## Copiar y pegar este prompt si la sesión se bloquea

---

Hola Claude. Soy Jose, fundador de MY HOST BizMate. Continuamos una sesión que se bloqueó.

## CONTEXTO RÁPIDO

MY HOST BizMate es una plataforma SaaS de automatización para hoteles boutique. Cliente piloto: Izumi Hotel (Ubud, Bali).

### Stack:
- n8n en Railway: https://n8n-production-bb2d.up.railway.app
- Supabase: jjpscimtxrudtepzwhag
- VAPI para Voice AI (KORA)
- ChakraHQ para WhatsApp

## ESTADO ACTUAL - LO QUE FUNCIONA ✅

1. **MCP Central v1 (Solo 2 Tools)** - ACTIVO
   - ID: `ydByDOQWq9kJACAe`
   - Path: `/mcp/izumi-hotel-v3`
   - Tools: check_availability + create_booking
   - VAPI/KORA usa este MCP

2. **WF-BOOKING-NOTIFICATIONS v1 FIXED** - ACTIVO
   - ID: `p3ukMWIbKN4bf5Gz`
   - Webhook: `/webhook/booking-notifications-v3`
   - Envía: WhatsApp Guest + WhatsApp Staff + Email

3. **Supabase Trigger** - ACTIVO
   - Se dispara cuando: INSERT en bookings con status='confirmed' AND channel='voice_ai'
   - Llama al webhook de notificaciones automáticamente

4. **Flujo completo probado y funcionando:**
   ```
   KORA (VAPI) → MCP Central → Supabase → Trigger → Notificaciones
   ```

## LO QUE ESTÁBAMOS HACIENDO - VAPI STRUCTURED OUTPUTS

**Objetivo:** Reactivar el MCP original con 6 tools (ID: `ueE1IdmobIqIAwwO`) usando VAPI Structured Outputs para que los datos lleguen consistentes.

**Problema actual:** El MCP con 6 tools falla porque cada tool usa `$fromAI()` independientemente y VAPI da datos diferentes/truncados en cada llamada (ej: teléfono incompleto).

**Solución:** VAPI Structured Outputs genera un JSON estructurado AL FINAL de la llamada con todos los datos validados.

### PROGRESO:

✅ **PASO 1 COMPLETADO:** JSON Schema diseñado (`callResult`)
- Un solo schema que combina: intent, booking data, contact, metrics, summary
- Required mínimos: intentType, tenantId, bookingCompleted
- El schema completo está en el documento adjunto

⏳ **PASO 2 EN PROGRESO:** Configurar Structured Output en VAPI Dashboard
- Ir a dashboard.vapi.ai → Structured Outputs → Create New
- Name: callResult
- Pegar el schema JSON
- Adjuntar al assistant KORA via artifactPlan.structuredOutputIds

⏳ **PASO 3 PENDIENTE:** Crear workflow WF-KORA-POST-CALL en n8n
- Recibe webhook de VAPI cuando termina la llamada
- Extrae el callResult
- Procesa según intentType (BOOKING, INQUIRY, etc.)

⏳ **PASO 4 PENDIENTE:** Reactivar MCP original con 6 tools

## IDs IMPORTANTES

```
# Supabase
Tenant ID (Izumi): c24393db-d318-4d75-8bbf-0fa240b9c1db
Property ID (Izumi): 18711359-1378-4d12-9ea6-fb31c0b1bac2

# n8n Workflows
MCP Central v1 (2 tools): ydByDOQWq9kJACAe
MCP Original (6 tools): ueE1IdmobIqIAwwO
WF-BOOKING-NOTIFICATIONS: p3ukMWIbKN4bf5Gz

# APIs
SendGrid From: zentaralivingubud@gmail.com
Staff WhatsApp: 34619794604
```

## DOCUMENTACIÓN VAPI STRUCTURED OUTPUTS

Referencia: https://docs.vapi.ai/assistants/structured-outputs-quickstart

Puntos clave:
- Se generan post-call (después de que termina la llamada)
- Se accede via: `call.artifact.structuredOutputs[outputId].result`
- Se configura en el assistant via `artifactPlan.structuredOutputIds`

## SIGUIENTE PASO

Continuar con PASO 2: Configurar el Structured Output `callResult` en VAPI Dashboard, o lo que me indiques.

---

**ADJUNTO:** El documento completo MYHOST_BIZMATE_DOCUMENTACION_16_ENERO_2026.md con toda la información técnica detallada.
