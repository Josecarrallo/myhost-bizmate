# MY HOST BizMate - Documentación Técnica Completa
## Fecha: 16 Enero 2026

---

## 1. RESUMEN EJECUTIVO

MY HOST BizMate es una plataforma SaaS de automatización para hoteles boutique y villas en el Sudeste Asiático. El cliente piloto es **Izumi Hotel** (7 villas de lujo en Ubud, Bali - apertura verano 2026).

### Stack Técnico
- **Frontend:** React en Vercel
- **Backend/DB:** Supabase (jjpscimtxrudtepzwhag)
- **Workflows:** n8n en Railway (https://n8n-production-bb2d.up.railway.app)
- **Voice AI:** VAPI
- **WhatsApp:** ChakraHQ API
- **Email:** SendGrid (pendiente migrar a Resend)

---

## 2. ARQUITECTURA DE AGENTES AI

| Agente | Función | Canal | Estado |
|--------|---------|-------|--------|
| 🌟 LUMINA | Sales & Leads CRM | UI Web | ⏳ Pendiente |
| 💧 BANYU | WhatsApp Concierge | WhatsApp | ✅ Funcionando |
| 📞 KORA | Voice Concierge | VAPI Calls | ✅ Funcionando |
| 👁️ OSIRIS | Operations Dashboard | UI Web | ⏳ Pendiente |

---

## 3. WORKFLOWS N8N - ESTADO ACTUAL

### ✅ ACTIVOS Y FUNCIONANDO

#### WF-BOOKING-NOTIFICATIONS v1 FIXED
- **ID:** `p3ukMWIbKN4bf5Gz`
- **Webhook:** `https://n8n-production-bb2d.up.railway.app/webhook/booking-notifications-v3`
- **Función:** Envía notificaciones automáticas cuando se crea un booking
- **Nodos:**
  - Webhook - New Booking (recibe datos del trigger Supabase)
  - Format Booking Data
  - Filter Confirmed Only
  - Get Property Info (Supabase)
  - WhatsApp to Guest (ChakraHQ)
  - WhatsApp to Staff (ChakraHQ) → número: 34619794604
  - Email to Guest (SendGrid) → from: zentaralivingubud@gmail.com

#### MCP Central v1 - Solo 2 Tools
- **ID:** `ydByDOQWq9kJACAe`
- **MCP Path:** `https://n8n-production-bb2d.up.railway.app/mcp/izumi-hotel-v3`
- **Función:** VAPI/KORA usa este MCP para check availability y crear bookings
- **Tools:**
  - `check_availability` → Supabase RPC
  - `create_booking` → POST a Supabase bookings table
- **IMPORTANTE:** Solo 2 tools. Las notificaciones van por Supabase Trigger.

#### BANYU v2 - WhatsApp AI Sales
- **ID:** `cYVfGnzuqnt3dmVN`
- **Webhook:** ChakraHQ WhatsApp
- **Función:** Agente de ventas por WhatsApp

#### WF-SP-01 Johnson Contract
- **ID:** `fHKGcfMtfu6CSNIH`
- **Función:** Procesa leads entrantes con Johnson Contract v1

### ❌ INACTIVOS (BACKUP/REFERENCIA)

#### MCP Central - Izumi Hotel MYHOST Bizmate XX (ORIGINAL con 6 tools)
- **ID:** `ueE1IdmobIqIAwwO`
- **MCP Path:** `/mcp/izumi-hotel`
- **Estado:** INACTIVO - Tiene problemas con $fromAI() en múltiples tools
- **Tools:** check_availability, create_booking, send_email, send_whatsapp_guest, send_whatsapp_staff
- **OBJETIVO:** Reactivar este workflow usando VAPI Structured Outputs para datos consistentes

---

## 4. SUPABASE - TRIGGER DE NOTIFICACIONES

### Trigger: booking_notification_trigger
```sql
-- Se dispara SOLO para bookings de VAPI (channel = 'voice_ai')
CREATE TRIGGER booking_notification_trigger
AFTER INSERT ON bookings
FOR EACH ROW
WHEN (NEW.status = 'confirmed' AND NEW.channel = 'voice_ai')
EXECUTE FUNCTION notify_booking_webhook();
```

### Función: notify_booking_webhook()
```sql
CREATE OR REPLACE FUNCTION notify_booking_webhook()
RETURNS TRIGGER 
SECURITY DEFINER
AS $$
BEGIN
  PERFORM net.http_post(
    'https://n8n-production-bb2d.up.railway.app/webhook/booking-notifications-v3'::text,
    jsonb_build_object(
      'id', NEW.id,
      'guest_name', NEW.guest_name,
      'guest_email', NEW.guest_email,
      'guest_phone', NEW.guest_phone,
      'check_in', NEW.check_in,
      'check_out', NEW.check_out,
      'guests', NEW.guests,
      'total_price', NEW.total_price,
      'status', NEW.status,
      'channel', NEW.channel,
      'property_id', NEW.property_id,
      'created_at', NEW.created_at
    ),
    '{}'::jsonb,
    '{"Content-Type": "application/json"}'::jsonb,
    5000
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

---

## 5. FLUJO ACTUAL COMPLETO (FUNCIONANDO)

```
LLAMADA A KORA (VAPI)
        ↓
VAPI usa MCP Central v1 (2 tools)
        ↓
┌─────────────────────────────────┐
│  check_availability             │ → Supabase RPC
│  create_booking                 │ → INSERT en bookings table
└─────────────────────────────────┘
        ↓
INSERT booking (status='confirmed', channel='voice_ai')
        ↓
Supabase Trigger: booking_notification_trigger
        ↓
pg_net.http_post() → /webhook/booking-notifications-v3
        ↓
WF-BOOKING-NOTIFICATIONS v1 FIXED (p3ukMWIbKN4bf5Gz)
        ↓
┌─────────────────────────────────┐
│  WhatsApp to Guest    ✅        │
│  WhatsApp to Staff    ✅        │
│  Email to Guest       ✅        │
└─────────────────────────────────┘
```

---

## 6. VAPI STRUCTURED OUTPUTS - EN PROGRESO

### Problema a resolver
El MCP original (6 tools) tiene problemas porque cada tool usa `$fromAI()` independientemente, y VAPI puede dar datos diferentes/truncados en cada llamada.

### Solución propuesta
Usar VAPI Structured Outputs para que al finalizar la llamada, VAPI envíe un JSON estructurado con todos los datos validados.

### JSON Schema diseñado: `callResult`
```json
{
  "name": "callResult",
  "description": "Resultado estructurado de la llamada de voz con toda la información necesaria para procesar reservas, leads y métricas.",
  "schema": {
    "type": "object",
    "properties": {
      "schemaVersion": {
        "type": "string",
        "description": "Versión del schema para control de cambios.",
        "default": "1.0.0"
      },
      "intentType": {
        "type": "string",
        "description": "Intención principal identificada en la llamada.",
        "enum": ["BOOKING", "INQUIRY", "CANCEL", "CHANGE", "SUPPORT", "OTHER"]
      },
      "intentConfidence": {
        "type": "string",
        "description": "Nivel de confianza en la clasificación del intent.",
        "enum": ["LOW", "MEDIUM", "HIGH"]
      },
      "bookingCompleted": {
        "type": "boolean",
        "description": "True si se completó una reserva durante la llamada."
      },
      "tenantId": {
        "type": "string",
        "description": "ID del tenant/hotel en el sistema. Para Izumi Hotel: c24393db-d318-4d75-8bbf-0fa240b9c1db"
      },
      "propertyId": {
        "type": "string",
        "description": "ID de la propiedad/villa seleccionada. Para Izumi Hotel: 18711359-1378-4d12-9ea6-fb31c0b1bac2"
      },
      "booking": {
        "type": "object",
        "description": "Datos de la reserva si se realizó o intentó realizar.",
        "properties": {
          "checkInDate": {
            "type": "string",
            "description": "Fecha de check-in en formato YYYY-MM-DD."
          },
          "checkOutDate": {
            "type": "string",
            "description": "Fecha de check-out en formato YYYY-MM-DD."
          },
          "numGuests": {
            "type": "integer",
            "description": "Número total de huéspedes.",
            "minimum": 1
          },
          "roomType": {
            "type": "string",
            "description": "Tipo de habitación/villa seleccionada."
          },
          "totalPrice": {
            "type": "number",
            "description": "Precio total de la reserva en USD."
          },
          "currency": {
            "type": "string",
            "description": "Moneda de la reserva.",
            "default": "USD"
          },
          "specialRequests": {
            "type": "string",
            "description": "Peticiones especiales del huésped."
          }
        }
      },
      "contact": {
        "type": "object",
        "description": "Datos de contacto del cliente.",
        "properties": {
          "name": {
            "type": "string",
            "description": "Nombre completo del cliente."
          },
          "phone": {
            "type": "string",
            "description": "Teléfono con código de país, formato: 34619794604 (sin +)."
          },
          "email": {
            "type": "string",
            "description": "Email del cliente."
          }
        }
      },
      "consent": {
        "type": "object",
        "description": "Permisos de comunicación obtenidos.",
        "properties": {
          "whatsappOk": {
            "type": "boolean",
            "description": "Cliente acepta recibir WhatsApp."
          },
          "emailOk": {
            "type": "boolean",
            "description": "Cliente acepta recibir emails."
          }
        }
      },
      "callSummary": {
        "type": "object",
        "description": "Resumen y metadatos de la llamada.",
        "properties": {
          "summary": {
            "type": "string",
            "description": "Resumen breve de lo que ocurrió en la llamada (2-3 frases)."
          },
          "language": {
            "type": "string",
            "description": "Idioma principal de la llamada.",
            "enum": ["en", "es", "id"]
          },
          "tags": {
            "type": "array",
            "description": "Etiquetas relevantes de la llamada.",
            "items": {
              "type": "string"
            }
          },
          "callSuccessful": {
            "type": "boolean",
            "description": "True si la llamada cumplió su objetivo."
          },
          "failureReason": {
            "type": "string",
            "description": "Razón del fallo si callSuccessful es false."
          }
        }
      },
      "metrics": {
        "type": "object",
        "description": "Métricas de calidad de la llamada.",
        "properties": {
          "sentiment": {
            "type": "string",
            "description": "Sentimiento general del cliente.",
            "enum": ["VERY_NEGATIVE", "NEGATIVE", "NEUTRAL", "POSITIVE", "VERY_POSITIVE"]
          },
          "leadScore": {
            "type": "integer",
            "description": "Puntuación del lead de 0 a 100.",
            "minimum": 0,
            "maximum": 100
          }
        }
      },
      "nextAction": {
        "type": "string",
        "description": "Acción recomendada después de la llamada.",
        "enum": ["SEND_CONFIRMATION", "CREATE_LEAD", "SCHEDULE_FOLLOWUP", "ESCALATE_HUMAN", "NO_ACTION"]
      },
      "internalNotes": {
        "type": "string",
        "description": "Notas internas para el equipo del hotel."
      }
    },
    "required": ["intentType", "tenantId", "bookingCompleted"],
    "additionalProperties": false
  }
}
```

### Pasos para implementar (PENDIENTE)
1. ✅ PASO 1: JSON Schema diseñado (arriba)
2. ⏳ PASO 2: Crear Structured Output en VAPI Dashboard
3. ⏳ PASO 3: Adjuntar al assistant KORA
4. ⏳ PASO 4: Configurar webhook en VAPI
5. ⏳ PASO 5: Crear workflow WF-KORA-POST-CALL en n8n
6. ⏳ PASO 6: Reactivar MCP original con 6 tools

---

## 7. IDs IMPORTANTES

### Supabase
- **Project:** jjpscimtxrudtepzwhag
- **Tenant ID (Izumi):** c24393db-d318-4d75-8bbf-0fa240b9c1db
- **Property ID (Izumi):** 18711359-1378-4d12-9ea6-fb31c0b1bac2

### n8n Workflows
- **MCP Central v1 (2 tools):** ydByDOQWq9kJACAe
- **MCP Central Original (6 tools):** ueE1IdmobIqIAwwO
- **WF-BOOKING-NOTIFICATIONS:** p3ukMWIbKN4bf5Gz
- **BANYU v2:** cYVfGnzuqnt3dmVN
- **WF-SP-01 Johnson:** fHKGcfMtfu6CSNIH

### APIs
- **ChakraHQ WhatsApp:** 2e45a0bd-8600-41b4-ac92-599d59d6221c
- **WhatsApp Phone ID:** 944855278702577
- **SendGrid From:** zentaralivingubud@gmail.com
- **Staff WhatsApp:** 34619794604

---

## 8. PENDIENTES

| Prioridad | Tarea | Estado |
|-----------|-------|--------|
| 🔴 Alta | VAPI Structured Outputs - Configurar en VAPI | En progreso |
| 🔴 Alta | WF-KORA-POST-CALL - Crear workflow | Pendiente |
| 🔴 Alta | Reactivar MCP original con 6 tools | Pendiente |
| 🟡 Media | Configurar Resend (reemplazar SendGrid) | Pendiente |
| 🟡 Media | LUMINA Follow-Up Engine | Pendiente |
| 🟢 Baja | Content Creator (Runway) | Pendiente |

---

## 9. CONTACTO IZUMI HOTEL
- **WhatsApp:** +62 813 2576 4867 (24/7)
- **Phone:** +62 813 2576 4867 (8:00-22:00)
- **Web:** www.my-host-bizmate.com

---

## 10. NOTAS TÉCNICAS

### n8n en Railway
- Versión actual: 1.123.5
- Evitar v2.0 por breaking changes
- Actualizar en Settings → Source → Source Image (lápiz)
- Rollback disponible en Deployments

### Reglas críticas
- No modificar JSONs de n8n sin mostrar antes/después
- Descripciones $fromAI() deben ser idénticas en todos los tools
- Toggle off/on para webhooks después de cambios
- Siempre verificar workflow activo antes de pruebas
