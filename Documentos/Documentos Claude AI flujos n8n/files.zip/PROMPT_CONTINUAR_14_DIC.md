# PROMPT PARA CONTINUAR - 14 Diciembre 2025

Copia y pega este prompt completo para continuar mañana:

---

## CONTEXTO DEL PROYECTO

Soy José, fundador de MY HOST BizMate, plataforma SaaS para gestión de villas y hoteles boutique en el sudeste asiático. Estoy implementando un chatbot de WhatsApp con capacidades multimodales (texto, imágenes, audio, documentos) para Izumi Hotel en Bali.

## INFRAESTRUCTURA

- **n8n:** https://n8n-production-bb2d.up.railway.app
- **Workflow ID:** ln2myAS3406D6F8W
- **WhatsApp:** +62 813 2576 4867 (vía ChakraHQ)
- **OpenAI Credential:** OpenAi account 4 (ID: hlVVk9ThwmKbr4yS)
- **ChakraHQ Token:** qiu1Z9eA3i2hhNjVM3Dm7QEK1Ey6iKQUE5IDWJlsFSAqXk5OlmQoD6DhqEwv9TOdgOVRWSYLWGxm6HfCs2LeCuwiU8Poqrw2Rgmvih0iEawZhoL6TTmMjVjvDUw2WuygAQgQ1vIeLCreDAKOGymGQCuR5bUYDHrRQQrvoMZLYwHw0LaGhFUuf4GxLpQbV3AQj8JDjhP2MzsCUYT4EVCARX6cODl1d1udr4pITGOmHQ793MUBtptq4XCvC8OGD3g

## ESTADO ACTUAL DEL WORKFLOW

### ✅ FUNCIONANDO:
1. **Mensajes de texto:** Webhook → Filter → Switch → AI Agent → HTTP Request
2. **Imágenes:** Switch → Download Image → Analyze image → Image (Edit Fields) → AI Agent

### ESTRUCTURA ACTUAL:
```
Webhook → Filter → Switch → [Text] → AI Agent → HTTP Request
                          → [Audio] (no implementado)
                          → [Image] → Download Image → Analyze image → Image → AI Agent
                          → [Document] (no implementado)
```

### CONFIGURACIÓN DEL NODO "Image" (Edit Fields):
- Field Name: `text` (minúscula)
- Field Value:
```
=User request on the image:
{{ "Describe the following image" || $('Webhook').item.json.body.entry[0].changes[0].value.messages[0].image.caption }}

Image description:
{{ $json.content[0].text }}
```

### AI Agent:
- Prompt: `={{ $json.text }}`

## TAREAS PENDIENTES PARA HOY

### 1. MEJORAR CLASIFICACIÓN DE IMÁGENES (PRIORITARIO)
**Problema:** Cuando envío imágenes no relacionadas con el hotel (logos, capturas), el AI fuerza conexión con Izumi Hotel.

**Solución:** Cambiar el prompt del nodo "Analyze image" a:
```
Analiza esta imagen de forma objetiva y describe exactamente lo que ves. 

Clasifica la imagen en una de estas categorías:
1. HOTEL_RELEVANTE: habitaciones, instalaciones, piscinas, restaurantes, spas, áreas comunes de hotel/villa
2. DOCUMENTO: reservas, comprobantes de pago, pasaportes, facturas, confirmaciones
3. NO_RELACIONADO: cualquier otra cosa (logos, capturas de pantalla, fotos personales, etc.)

Formato de respuesta:
CATEGORÍA: [categoría]
DESCRIPCIÓN: [descripción objetiva de lo que ves]

Si es DOCUMENTO, extrae los datos importantes (fechas, nombres, números de reserva, montos).
Si es NO_RELACIONADO, indica claramente que la imagen no está relacionada con servicios hoteleros.

Responde en español.
```

### 2. IMPLEMENTAR AUDIO BRANCH
Patrón a seguir:
```
Switch → [Audio] → Download Audio → Transcribe (OpenAI Whisper) → Audio (Edit Fields) → AI Agent
```

Endpoint para descargar audio:
```
https://api.chakrahq.com/v1/whatsapp/v19.0/media/{{ $json.body.entry[0].changes[0].value.messages[0].audio.id }}/show
```

### 3. IMPLEMENTAR DOCUMENT/PDF BRANCH
```
Switch → [Document] → Download Document → Extract Text → Document (Edit Fields) → AI Agent
```

### 4. NORMALIZAR RAMA DE TEXTO
Crear nodo "Text" (Edit Fields) para consistencia:
```
Switch → [Text] → Text (Edit Fields) → AI Agent
```

## LECCIONES APRENDIDAS (IMPORTANTE)

1. OpenAI node v2 genera `content[0].text`, no `content`
2. n8n es case-sensitive: `text` ≠ `Text`
3. Expresiones empiezan con un solo `=`, no `==`
4. ChakraHQ media endpoint: `https://api.chakrahq.com/v1/whatsapp/v19.0/media/{mediaId}/show`
5. Referencias cruzadas: `$('NodeName').item.json.field`

## ARCHIVOS DE REFERENCIA

Los transcripts detallados están en:
- `/mnt/transcripts/2025-12-13-10-42-36-whatsapp-multimodal-image-chakrahq-setup.txt`
- `/mnt/transcripts/2025-12-13-12-15-32-whatsapp-image-multimodal-chakrahq-troubleshooting.txt`

El template de referencia está en GitHub: `Zie619/n8n-workflows` (workflow 3586)

---

**EMPEZAMOS:** Por favor, ayúdame primero a implementar la mejora de clasificación de imágenes en el nodo "Analyze image".
