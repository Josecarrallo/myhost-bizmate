export { default } from './SmartPricing';
