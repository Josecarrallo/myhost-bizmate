import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  Target,
  Palette,
  MessageSquare,
  PhoneCall,
  Lightbulb,
  BarChart3,
  Users,
  DollarSign,
  Calendar,
  TrendingUp,
  ArrowUp,
  ArrowDown,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

const AISystems = ({ onBack }) => {
  const [selectedAgent, setSelectedAgent] = useState('osiris');
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const lastMessageRef = useRef(null);

  // Agent definitions with corporate orange theme
  const agents = {
    osiris: {
      id: 'osiris',
      name: 'OSIRIS',
      fullName: 'OSIRIS.AI',
      description: 'Operations & Control',
      icon: Bot,
      gradient: 'from-[#d85a2a] via-[#e67e50] to-[#f5a524]',
      glowColor: 'shadow-[#d85a2a]/50',
      quickQuestions: [
        "What's my occupancy for next 7 days?",
        "Show pending payments",
        "Any active alerts?",
        "Today's check-ins"
      ]
    },
    lumina: {
      id: 'lumina',
      name: 'LUMINA',
      fullName: 'LUMINA.AI',
      description: 'Sales & Leads',
      icon: Target,
      gradient: 'from-[#FF6B35] via-[#FF8C42] to-[#FFA94D]',
      glowColor: 'shadow-orange-500/50',
      quickQuestions: [
        "Show hot leads",
        "Pending follow-ups",
        "Lead conversion rate",
        "Draft follow-up message"
      ]
    },
    iris: {
      id: 'iris',
      name: 'IRIS',
      fullName: 'IRIS.AI',
      description: 'Marketing Intelligence',
      icon: Palette,
      gradient: 'from-purple-500 via-pink-500 to-rose-400',
      glowColor: 'shadow-purple-500/50',
      quickQuestions: [
        "Content ideas for this week",
        "Review performance",
        "Draft Instagram post",
        "Campaign summary"
      ]
    },
    banyu: {
      id: 'banyu',
      name: 'BANYU',
      fullName: 'BANYU.AI',
      description: 'WhatsApp Concierge',
      icon: MessageSquare,
      gradient: 'from-emerald-500 via-green-500 to-teal-400',
      glowColor: 'shadow-emerald-500/50',
      quickQuestions: [
        "Active conversations",
        "Messages today",
        "Send welcome message",
        "Response time stats"
      ]
    },
    kora: {
      id: 'kora',
      name: 'KORA',
      fullName: 'KORA.AI',
      description: 'Voice Assistant',
      icon: PhoneCall,
      gradient: 'from-blue-500 via-indigo-500 to-violet-400',
      glowColor: 'shadow-blue-500/50',
      quickQuestions: [
        "Today's calls",
        "Call duration average",
        "Sentiment analysis",
        "Missed calls"
      ]
    },
    aura: {
      id: 'aura',
      name: 'AURA',
      fullName: 'AURA.AI',
      description: 'Insights & Predictions',
      icon: Lightbulb,
      gradient: 'from-amber-400 via-yellow-500 to-orange-400',
      glowColor: 'shadow-amber-500/50',
      quickQuestions: [
        "Revenue forecast",
        "Market trends",
        "Optimization suggestions",
        "Anomaly detection"
      ]
    }
  };

  const currentAgent = agents[selectedAgent];

  // Welcome message when agent changes
  useEffect(() => {
    const welcomeMessage = {
      type: 'assistant',
      agent: selectedAgent,
      content: `Hello! I'm ${currentAgent.fullName}, your ${currentAgent.description} assistant. How can I help you today?`,
      timestamp: new Date()
    };
    setMessages([welcomeMessage]);
  }, [selectedAgent]);

  // Auto-scroll - for assistant messages, scroll to TOP to show text first
  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.type === 'assistant' && lastMessageRef.current) {
        // For assistant messages (especially OSIRIS with long responses),
        // scroll to show the TOP of the message so user sees text first
        lastMessageRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else {
        // For user messages, scroll to bottom as normal
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage = {
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentQuestion = inputMessage;
    setInputMessage('');
    setIsLoading(true);

    try {
      // OSIRIS: Call real n8n endpoint V2
      if (selectedAgent === 'osiris') {
        const response = await fetch('https://n8n-production-bb2d.up.railway.app/webhook/ai/chat-v2', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            tenant_id: 'c24393db-d318-4d75-8bbf-0fa240b9c1db',
            message: currentQuestion
          })
        });

        if (!response.ok) {
          throw new Error(`Workflow not ready (HTTP ${response.status}). Ask Claude AI to finish WF-OSIRIS-MVP setup.`);
        }

        // Check if response has content
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          throw new Error('Workflow is not returning JSON. The WF-OSIRIS-MVP workflow may not be active yet.');
        }

        const text = await response.text();
        if (!text || text.trim().length === 0) {
          throw new Error('Workflow returned empty response. WF-OSIRIS-MVP is not configured yet. Ask Claude AI to complete the setup.');
        }

        let data;
        try {
          data = JSON.parse(text);
        } catch (parseError) {
          console.error('JSON parse error:', parseError);
          console.error('Response text:', text);
          throw new Error('Workflow returned invalid JSON. Check n8n workflow configuration.');
        }

        // Validate response structure
        if (!data.reply) {
          throw new Error('Workflow response missing "reply" field. WF-OSIRIS-MVP needs configuration review.');
        }

        // Log full response for debugging
        console.log('✅ OSIRIS Response:', data);

        const assistantMessage = {
          type: 'assistant',
          agent: 'osiris',
          content: data.reply,
          kpis: data.kpis || null,
          table: data.table || null,
          actions: data.actions || null,
          meta: data.meta || null,
          timestamp: new Date()
        };

        console.log('📨 Assistant Message:', assistantMessage);

        setMessages(prev => [...prev, assistantMessage]);
      } else {
        // Other agents: Use mock response
        setTimeout(() => {
          const mockResponse = {
            type: 'assistant',
            agent: selectedAgent,
            content: getMockResponse(selectedAgent, currentQuestion),
            timestamp: new Date()
          };
          setMessages(prev => [...prev, mockResponse]);
        }, 1500);
      }
    } catch (error) {
      console.error('Error calling OSIRIS:', error);
      const errorMessage = {
        type: 'assistant',
        agent: selectedAgent,
        content: `❌ Sorry, I encountered an error: ${error.message}. Please try again.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickQuestion = (question) => {
    setInputMessage(question);
  };

  const getMockResponse = (agent, question) => {
    // Mock responses for demo
    const responses = {
      lumina: "Here's your sales summary:\n\n🎯 **Hot Leads:** 5 leads with high engagement\n\n📧 **Pending Follow-ups:** 8 leads need contact\n\n📈 **Conversion Rate:** 23% (last 30 days)\n\nShall I draft follow-up messages for the hot leads?",
      iris: "Marketing insights:\n\n✨ **Content Ideas:** Beach sunset posts, villa tours, guest testimonials\n\n⭐ **Review Performance:** 4.8 avg rating (last month)\n\n📱 **Best Time to Post:** 6-8 PM local time\n\nWant me to create a content calendar?",
      banyu: "WhatsApp status:\n\n💬 **Active Conversations:** 12 guests\n\n📨 **Messages Today:** 47 messages\n\n⚡ **Avg Response Time:** 3.2 minutes\n\nNeed help with any specific conversation?",
      kora: "Voice activity:\n\n📞 **Calls Today:** 8 calls\n\n⏱️ **Avg Duration:** 4m 32s\n\n😊 **Sentiment:** 85% positive\n\nAny call you'd like to review?",
      aura: "Market intelligence:\n\n📈 **Revenue Forecast:** +15% next month\n\n🌴 **Bali Trends:** High season starting\n\n💡 **Recommendation:** Increase rates 10-15%\n\nWant detailed analysis?"
    };

    return responses[agent] || "I'm here to help! Ask me anything.";
  };

  const AgentIcon = currentAgent.icon;

  // Render KPIs as cards - COMPACT
  const renderKPIs = (kpis) => {
    if (!kpis || !Array.isArray(kpis) || kpis.length === 0) return null;

    try {
      return (
        <div className="grid grid-cols-2 gap-2 mt-3">
          {kpis.map((kpi, index) => {
          const isPositive = kpi.delta && kpi.delta.startsWith('+');
          const isNegative = kpi.delta && kpi.delta.startsWith('-');

          return (
            <div key={index} className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10">
              <p className="text-[10px] text-orange-300 font-medium mb-0.5">{kpi.label}</p>
              <div className="flex items-baseline gap-1.5">
                <p className="text-lg font-bold text-white">{kpi.value}</p>
                {kpi.delta && (
                  <span className={`text-[10px] font-semibold flex items-center gap-0.5 ${
                    isPositive ? 'text-green-400' : isNegative ? 'text-red-400' : 'text-gray-400'
                  }`}>
                    {isPositive && <ArrowUp className="w-2.5 h-2.5" />}
                    {isNegative && <ArrowDown className="w-2.5 h-2.5" />}
                    {kpi.delta}
                  </span>
                )}
              </div>
            </div>
          );
        })}
        </div>
      );
    } catch (error) {
      console.error('Error rendering KPIs:', error);
      return <div className="mt-3 text-red-400 text-xs">Error displaying KPIs</div>;
    }
  };

  // Render table - COMPACT
  const renderTable = (table) => {
    if (!table || !table.rows || !Array.isArray(table.rows) || table.rows.length === 0) return null;
    if (!table.columns || !Array.isArray(table.columns)) return null;

    try {
      return (
        <div className="mt-3 overflow-x-auto">
          <div className="bg-white/5 backdrop-blur-sm rounded-lg border border-white/10 overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-white/10">
                <tr>
                  {table.columns.map((col, index) => (
                  <th key={index} className="px-3 py-2 text-left text-[10px] font-semibold text-orange-300 uppercase tracking-wider">
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {table.rows.slice(0, 10).map((row, rowIndex) => (
                <tr key={rowIndex} className="hover:bg-white/5 transition-colors">
                  {table.columns.map((col, colIndex) => (
                    <td key={colIndex} className="px-3 py-2 text-white/90">
                      {row[col.key]}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
            {table.row_count > 10 && (
              <div className="bg-white/5 px-3 py-1.5 text-center text-[10px] text-orange-300">
                Showing 10 of {table.row_count} rows
              </div>
            )}
          </div>
        </div>
      );
    } catch (error) {
      console.error('Error rendering table:', error);
      return <div className="mt-3 text-red-400 text-xs">Error displaying table</div>;
    }
  };

  // Render action buttons - COMPACT
  const renderActions = (actions) => {
    if (!actions || !Array.isArray(actions) || actions.length === 0) return null;

    try {
      return (
        <div className="flex flex-wrap gap-1.5 mt-3">
          {actions.map((action, index) => (
          <button
            key={index}
            onClick={() => {
              console.log('Action clicked:', action);
              // TODO: Implement action execution
              alert(`Action "${action.label}" - Implementation pending`);
            }}
            className="px-3 py-1.5 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700
                     text-white text-xs font-medium rounded-lg
                     transition-all duration-200 hover:scale-105 hover:shadow-lg
                     flex items-center gap-1.5"
          >
            {action.needs_confirm ? (
              <AlertCircle className="w-3 h-3" />
            ) : (
              <CheckCircle className="w-3 h-3" />
            )}
            {action.label}
            </button>
          ))}
        </div>
      );
    } catch (error) {
      console.error('Error rendering actions:', error);
      return <div className="mt-3 text-red-400 text-xs">Error displaying actions</div>;
    }
  };

  return (
    <div className="flex-1 h-screen bg-gradient-to-br from-[#1a1f2e] via-[#2a2f3a] to-[#1a1f2e] flex flex-col overflow-hidden">
      {/* Header - COMPACT for maximum chat space */}
      <div className="bg-gradient-to-r from-white/10 via-white/5 to-white/10 backdrop-blur-xl border-b border-orange-500/20 p-3 shadow-2xl">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`
              w-12 h-12 rounded-xl bg-gradient-to-br ${currentAgent.gradient}
              flex items-center justify-center shadow-xl ${currentAgent.glowColor}
              ring-2 ring-white/20
            `}>
              <AgentIcon className="w-6 h-6 text-white drop-shadow-lg" />
            </div>
            <div>
              <h2 className="text-xl font-bold bg-gradient-to-r from-white via-orange-200 to-white bg-clip-text text-transparent">
                {currentAgent.fullName}
              </h2>
              <p className="text-xs text-orange-300 font-medium">{currentAgent.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 bg-gradient-to-r from-[#d85a2a] to-[#f5a524] rounded-full">
              <Sparkles className="w-4 h-4 text-white animate-pulse" />
            </div>
          </div>
        </div>

        {/* Agent Selector - COMPACT with PROMINENT names */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
          {Object.values(agents).map((agent) => {
            const Icon = agent.icon;
            const isActive = selectedAgent === agent.id;
            return (
              <button
                key={agent.id}
                onClick={() => setSelectedAgent(agent.id)}
                className={`
                  group relative flex flex-col items-center gap-2 p-2.5 rounded-xl
                  transition-all duration-300 transform
                  ${isActive
                    ? `bg-gradient-to-br ${agent.gradient} text-white shadow-xl ${agent.glowColor}
                       scale-105 ring-2 ring-white/30`
                    : 'bg-white/5 text-white/70 hover:bg-white/10 hover:scale-105 hover:shadow-lg'
                  }
                `}
              >
                {/* Icon Container */}
                <div className={`
                  w-10 h-10 rounded-lg flex items-center justify-center
                  transition-transform duration-300
                  ${isActive
                    ? 'bg-white/20'
                    : 'bg-white/10 group-hover:bg-white/20'
                  }
                `}>
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-white/80'}`} />
                </div>

                {/* Agent Name - PROMINENT */}
                <span className={`text-sm font-black uppercase tracking-wide ${
                  isActive
                    ? 'text-white drop-shadow-lg'
                    : 'text-white/95 group-hover:text-white'
                }`}>
                  {agent.name}
                </span>

                {/* Active Indicator */}
                {isActive && (
                  <div className="absolute -top-0.5 -right-0.5">
                    <div className="w-2.5 h-2.5 bg-white rounded-full animate-pulse" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Chat Area - MAXIMUM SPACE */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-transparent to-black/20">
        {messages.map((message, index) => {
          const isLastMessage = index === messages.length - 1;
          return (
            <div
              key={index}
              ref={isLastMessage ? lastMessageRef : null}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn`}
            >
            <div
              className={`
                max-w-[85%] rounded-xl p-4 shadow-lg
                ${message.type === 'user'
                  ? 'bg-gradient-to-br from-[#d85a2a] via-[#e67e50] to-[#f5a524] text-white ring-2 ring-orange-400/30'
                  : 'bg-white/10 backdrop-blur-md text-white border-2 border-white/20'
                }
              `}
            >
              {message.type === 'assistant' && (
                <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/20">
                  <div className={`w-6 h-6 rounded-lg bg-gradient-to-br ${currentAgent.gradient} flex items-center justify-center`}>
                    <AgentIcon className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-orange-300 font-semibold text-xs">{currentAgent.fullName}</span>
                </div>
              )}
              <p className="whitespace-pre-wrap leading-relaxed text-sm">{message.content}</p>

              {/* Render KPIs */}
              {message.kpis && renderKPIs(message.kpis)}

              {/* Render Table */}
              {message.table && renderTable(message.table)}

              {/* Render Actions */}
              {message.actions && renderActions(message.actions)}

              <p className="text-[10px] opacity-70 mt-2 text-right">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
          );
        })}

        {isLoading && (
          <div className="flex justify-start animate-fadeIn">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border-2 border-white/20 shadow-lg">
              <div className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-lg bg-gradient-to-br ${currentAgent.gradient} flex items-center justify-center animate-pulse`}>
                  <AgentIcon className="w-3 h-3 text-white" />
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Bar - COMPACT with quick questions below */}
      <div className="bg-gradient-to-r from-white/10 via-white/5 to-white/10 backdrop-blur-xl border-t border-orange-500/20 p-3 shadow-2xl">
        <div className="flex gap-3 mb-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={`Ask ${currentAgent.name} anything...`}
            className="flex-1 bg-white/10 text-white placeholder-orange-300/50 rounded-xl px-4 py-3
                     border-2 border-white/20 focus:outline-none focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20
                     transition-all duration-300 backdrop-blur-sm text-base"
            disabled={isLoading}
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isLoading}
            className={`
              px-6 py-3 rounded-xl font-bold transition-all duration-300 transform
              ${inputMessage.trim() && !isLoading
                ? `bg-gradient-to-br ${currentAgent.gradient} text-white
                   hover:scale-105 hover:shadow-xl ${currentAgent.glowColor}
                   ring-2 ring-white/30 active:scale-95`
                : 'bg-white/5 text-white/30 cursor-not-allowed'
              }
            `}
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Questions - COMPACT */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {currentAgent.quickQuestions.map((question, index) => (
            <button
              key={index}
              onClick={() => handleQuickQuestion(question)}
              className="px-3 py-1.5 bg-gradient-to-r from-white/10 to-white/5 hover:from-orange-500/20 hover:to-orange-600/20
                       text-white text-xs font-medium rounded-lg whitespace-nowrap
                       border border-white/20 hover:border-orange-400/50
                       transition-all duration-200 hover:scale-105"
            >
              {question}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AISystems;
