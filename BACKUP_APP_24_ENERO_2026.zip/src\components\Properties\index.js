export { default } from './Properties';
