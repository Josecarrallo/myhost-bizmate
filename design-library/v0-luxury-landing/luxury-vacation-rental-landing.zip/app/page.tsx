import { PublicSite } from "@/components/public-site"

export default function LandingPage() {
  return <PublicSite />
}
