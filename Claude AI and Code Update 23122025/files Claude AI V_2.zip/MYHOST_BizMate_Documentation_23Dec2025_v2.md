# MY HOST BizMate - DOCUMENTACIÓN COMPLETA
## Actualizado: 23 Diciembre 2025 - 18:00 SGT

---

## 1. RESUMEN EJECUTIVO

**MY HOST BizMate** es una plataforma SaaS de automatización para hoteles boutique y villas en el sudeste asiático. Proporciona gestión de propiedades, comunicación con huéspedes via WhatsApp, y asistente IA para propietarios.

**Cliente piloto:** Izumi Hotel (Ubud, Bali) - 7 villas de lujo

---

## 2. STACK TECNOLÓGICO

| Componente | Tecnología | URL/Detalles |
|------------|------------|--------------|
| **Workflows** | n8n (Railway) | https://n8n-production-bb2d.up.railway.app |
| **Base de datos** | Supabase | Credential ID: SJLQzwU9BVHEVAGc |
| **IA** | Claude API | claude-sonnet-4-20250514 |
| **WhatsApp** | ChakraHQ | Pendiente integración |
| **Voice** | Vapi.ai | En desarrollo |
| **Frontend** | React + Vercel | En desarrollo |

---

## 3. WORKFLOWS ACTIVOS

### WF1 - Owner Daily Intelligence
| Campo | Valor |
|-------|-------|
| **ID** | LpYnfKx9LOmqWv3s |
| **Estado** | ✅ Activo |
| **Trigger** | Cron diario 9:00 AM SGT |
| **Función** | Envía KPIs diarios por WhatsApp al owner |
| **Pendiente** | Verificar ejecución mañana 24 Dic 9AM |

### WF-IA-01 - Owner AI Assistant
| Campo | Valor |
|-------|-------|
| **ID** | iAMo7NdzYkJxJUkP |
| **Estado** | ✅ Activo |
| **Trigger** | Webhook POST |
| **URL** | https://n8n-production-bb2d.up.railway.app/webhook/owner-ai-assistant |
| **Función** | Chat interactivo con IA para consultas del owner |
| **Pendiente** | Revisar prompt - IA inventa datos |

### WF-IA-02 - Owner AI Recommendation
| Campo | Valor |
|-------|-------|
| **ID** | (verificar en n8n) |
| **Estado** | ✅ Activo |
| **Trigger** | Cron diario 8:00 AM SGT |
| **Función** | Alertas automáticas proactivas |

### WF-IA-03 - Action Executor
| Campo | Valor |
|-------|-------|
| **Estado** | ❌ NO CONSTRUIDO |
| **Función** | Ejecutar acciones sugeridas por IA |

---

## 4. BASE DE DATOS SUPABASE

### 4.1 Datos Actuales (Demo Izumi Hotel)

| Tabla | Registros | Descripción |
|-------|-----------|-------------|
| **properties** | 7 | Villas de Izumi Hotel |
| **guests** | 15 | Huéspedes internacionales |
| **bookings** | 50 | 35 históricos + 4 in-house + 10 futuros + 1 cancelación |
| **payments** | 14 | $74,950 USD total |
| **messages** | 8 | Conversaciones WhatsApp ejemplo |

### 4.2 Propiedades Izumi Hotel

| Villa | Bedrooms | Max Guests | Base Price/Night |
|-------|----------|------------|------------------|
| River Villa | 2 | 4 | $500 |
| Nest Villa | 2 | 4 | $525 |
| Cave Villa | 2 | 4 | $550 |
| Sky Villa | 2 | 4 | $550 |
| Blossom Villa | 2 | 4 | $600 |
| Tropical Room | 1 | 2 | $450 |
| 5BR Grand Villa | 5 | 12 | $2,500 |

### 4.3 Constraints Importantes

**bookings.status** (valores permitidos):
- `inquiry`
- `confirmed`
- `checked_in`
- `checked_out`
- `cancelled`

**bookings.channel** (valores permitidos):
- `direct`
- `airbnb`
- `booking`
- `expedia`
- `agoda`
- `vrbo`

**bookings.payment_status** (valores permitidos):
- `pending`
- `partial`
- `paid`
- `refunded`

### 4.4 Triggers Activos (8 total)

| Trigger | Tabla | Función |
|---------|-------|---------|
| calculate_nights_trigger | bookings (INSERT/UPDATE) | Calcula noches automáticamente |
| update_properties_updated_at | properties | Actualiza timestamp |
| update_bookings_updated_at | bookings | Actualiza timestamp |
| update_alerts_updated_at | alerts | Actualiza timestamp |
| on_booking_insert | bookings | notify_booking_created() |
| on_property_insert | properties | notify_property_registered() |
| new_booking_notification | bookings | Webhook a n8n |

### 4.5 Funciones Activas (16 total)

**Webhooks:**
- `notify_property_registered()` → /webhook/new-property-notification
- `notify_booking_created()` → /webhook/booking-created

**Utilidades:**
- `calculate_nights()`
- `calculate_booking_price()`
- `check_availability()`
- `update_booking_payment_status()`
- `generate_confirmation_code()`
- `update_updated_at_column()`

**Dashboard:**
- `get_dashboard_stats()`
- `get_today_checkins()`
- `get_today_checkouts()`
- `get_total_revenue()`
- `get_pending_payments_total()`
- `get_unread_messages_count()`
- `get_ai_handled_messages_count()`
- `get_active_alerts()`

---

## 5. CREDENCIALES

| Servicio | Credencial |
|----------|------------|
| **Supabase** | Credential ID: SJLQzwU9BVHEVAGc |
| **Claude API** | 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 |
| **n8n URL** | https://n8n-production-bb2d.up.railway.app |

---

## 6. PROBLEMAS CONOCIDOS Y PENDIENTES

### 6.1 CRÍTICO - WF-IA-01 Inventa Datos
**Problema:** Claude inventa números que no corresponden a los datos reales
- Dijo "$150,850 revenue" cuando real es $21,550
- Dijo "35 reservas confirmadas" cuando real es 10

**Solución pendiente:** Revisar y ajustar el prompt del nodo "Claude AI Response" para que sea más estricto con los datos proporcionados.

### 6.2 Pendientes Inmediatos
1. ✅ ~~Limpiar datos de prueba~~
2. ✅ ~~Insertar datos demo Izumi Hotel~~
3. ✅ ~~Corregir estados en KPI Calculator~~
4. ⏳ Verificar WF1 mañana 9AM
5. ⏳ Ajustar prompt Claude (no inventar datos)
6. ⏳ Añadir métrica cancelaciones al KPI Calculator

### 6.3 Pendientes Corto Plazo
- WF-IA-03 Action Executor
- Integración Vapi.ai
- Integración ChakraHQ WhatsApp

---

## 7. CONTACTO IZUMI HOTEL

- **WhatsApp:** +62 813 2576 4867 (24/7)
- **Phone:** +62 813 2576 4867 (8:00-22:00)
- **Web:** www.my-host-bizmate.com

---

## 8. HISTORIAL DE SESIONES

### 23 Dic 2025 - Sesión Principal
- Backup de triggers y funciones completado
- Limpieza de datos de prueba
- Inserción de 50 bookings demo
- Corrección de WF-IA-01 (estados de booking)
- Actualización de fechas a 2025
- Prueba exitosa de WF-IA-01

---

*Documento generado: 23 Diciembre 2025*
