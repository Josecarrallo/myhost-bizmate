# PROMPT DE ARRANQUE - MY HOST BizMate
## Copiar y pegar al inicio de cada nueva sesión de Claude

---

Soy José, fundador de MY HOST BizMate. Necesito continuar trabajando en mi plataforma SaaS de gestión hotelera.

## CONTEXTO DEL PROYECTO

**MY HOST BizMate** es una plataforma de automatización para hoteles boutique y villas en Bali/Southeast Asia. Cliente piloto: Izumi Hotel (7 villas de lujo en Ubud).

## STACK TECNOLÓGICO

- **n8n** (workflows): https://n8n-production-bb2d.up.railway.app
- **Supabase** (database): Credential ID: SJLQzwU9BVHEVAGc
- **Claude API**: claude-sonnet-4-20250514
- **Timezone**: Asia/Singapore

## WORKFLOWS ACTIVOS

| Workflow | ID | Estado | Función |
|----------|-----|--------|---------|
| WF1 - Owner Daily Intelligence | LpYnfKx9LOmqWv3s | ✅ Activo | KPIs diarios 9AM SGT |
| WF-IA-01 - Owner AI Assistant | iAMo7NdzYkJxJUkP | ✅ Activo | Chat webhook |
| WF-IA-02 - Owner AI Recommendation | (verificar) | ✅ Activo | Alertas 8AM SGT |
| WF-IA-03 - Action Executor | N/A | ❌ No construido | Ejecutar acciones |

## DATOS EN SUPABASE (Demo Izumi Hotel)

| Tabla | Registros |
|-------|-----------|
| properties | 7 villas |
| guests | 15 |
| bookings | 50 (35 históricos + 4 in-house + 10 futuros + 1 cancelación) |
| payments | 14 ($74,950 USD) |
| messages | 8 |

**Fechas de datos:** Oct 2025 - Ene 2026 (actualizadas a fecha actual)

## CONSTRAINTS IMPORTANTES

**bookings.status:** inquiry, confirmed, checked_in, checked_out, cancelled
**bookings.channel:** direct, airbnb, booking, expedia, agoda, vrbo
**bookings.payment_status:** pending, partial, paid, refunded

## PENDIENTES INMEDIATOS

1. **WF1** - Verificar que funciona correctamente (debió ejecutarse 24 Dic 9AM SGT)
2. **WF-IA-01** - PROBLEMA: Claude inventa datos
   - Dijo "$150,850 revenue" cuando real es $21,550
   - Dijo "35 reservas" cuando real es 10
   - **Solución:** Revisar prompt del nodo "Claude AI Response" para que NO invente
3. **WF-IA-01** - Añadir métrica de cancelaciones recientes

## PENDIENTES CORTO PLAZO

4. WF-IA-03 - Action Executor (construir)
5. Integración Vapi.ai (voice)
6. Integración ChakraHQ (WhatsApp)

## MIS PREFERENCIAS

- Respuestas en español
- Soluciones completas y probadas, no prueba y error
- Documentar todo para continuidad
- Verificar estructura de tablas antes de escribir SQL

## CREDENCIALES

- Supabase: SJLQzwU9BVHEVAGc
- Claude API: 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
- Webhook WF-IA-01: https://n8n-production-bb2d.up.railway.app/webhook/owner-ai-assistant

## CONTACTO IZUMI HOTEL

WhatsApp: +62 813 2576 4867

---

**TAREA PARA ESTA SESIÓN:** [Escribe aquí qué quieres hacer]
