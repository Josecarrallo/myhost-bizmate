# PROMPT PARA NUEVA SESIÓN - MY HOST BizMate
## Última actualización: 23 Diciembre 2025

---

## CONTEXTO DEL PROYECTO

Soy José Carrallo, fundador de **MY HOST BizMate**, una plataforma SaaS de gestión hotelera con automatización AI para boutique hotels y villas en Bali, Indonesia.

### Stack Tecnológico
- **Frontend**: React + Tailwind CSS + Framer Motion (desplegado en Vercel)
- **Backend/DB**: Supabase (PostgreSQL)
- **Workflows**: n8n (desplegado en Railway)
- **AI**: Claude API (Anthropic)
- **WhatsApp**: ChakraHQ Business API
- **Voice**: Vapi.ai (en desarrollo)

### Cliente Piloto
**Izumi Hotel** - Boutique hotel 5 estrellas en Ubud, Bali (apertura verano 2026)
- 7 tipos de habitación: River Villa ($500), Nest Villa ($525), Cave Villa ($550), 5BR Villa ($2,500), Blossom Villa ($600), Sky Villa ($550), Tropical Room ($450)

---

## ESTADO ACTUAL DE WORKFLOWS (23 Dic 2025)

### Workflows Activos ✅
1. **WF1 - Owner Daily Intelligence** (ID: aergpRINvoJEyufR)
   - Cron: 9AM hora Singapur
   - Función: Envía KPIs diarios por WhatsApp
   - Webhook: https://n8n-production-bb2d.up.railway.app/webhook/owner-daily-intelligence

2. **WF-IA-01 - Owner AI Assistant** (ID: iAMo7NdzYkJxJUkP)
   - Trigger: Webhook POST
   - Función: Chat interactivo con IA para consultas del propietario
   - Webhook: https://n8n-production-bb2d.up.railway.app/webhook/owner-ai-assistant
   - ⚠️ IMPORTANTE: Response Mode debe ser "Using 'Respond to Webhook' Node"

3. **WF-IA-02 - Owner AI Recommendation** (ID: vDlWuAbhQkbut0Ei)
   - Cron: 8AM hora Singapur
   - Función: Genera alertas automáticas basadas en reglas de negocio
   - Reglas: ocupación baja, sin reservas, cancelaciones altas, check-ins pendientes

4. **WF-Property - New Property Notification**
   - Trigger: Supabase INSERT en tabla properties
   - Función: Envía email y WhatsApp cuando se registra nueva propiedad

5. **WF-Booking - Booking Confirmation**
   - Trigger: Supabase INSERT en tabla bookings
   - Función: Envía confirmación por email y WhatsApp

### Workflows Pendientes ⏳
- **WF-IA-03 - Action Executor**: Ejecutar acciones sugeridas por la IA
- **WF-Vapi - Voice Assistant**: Integración con Vapi.ai

---

## TABLAS DE SUPABASE

### Tablas Principales
- properties, bookings, guests, payments, messages, users

### Tablas de IA/Workflows (creadas recientemente)
- alerts, ai_chat_history, recommendation_logs, workflow_logs, audit_logs, ops_tasks, owner_insights

### Modificaciones Realizadas
Las siguientes columnas fueron añadidas:
- **alerts**: tenant_id, alert_type, title, description, property_id, resolved_at
- **ai_chat_history**: tenant_id, user_id, answer, suggested_actions
- **audit_logs**: tenant_id, action_type, payload_in, payload_out

---

## CREDENCIALES

### IDs de Prueba
- Tenant ID: `00000000-0000-0000-0000-000000000000`
- User ID: `00000000-0000-0000-0000-000000000001`

### n8n
- URL Base: `https://n8n-production-bb2d.up.railway.app`
- Supabase Credential ID: `SJLQzwU9BVHEVAGc`

### APIs
- Claude API: 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

---

## TAREAS PENDIENTES

### Inmediatas
1. Verificar triggers de Supabase (para documentar)
2. Limpiar datos de prueba en Supabase
3. Crear datos de demo coherentes para Izumi Hotel (7 villas) + Villa Demo (3 villas)
4. Construir WF-IA-03 Action Executor

### Próximas
- Completar integración Vapi.ai
- Dashboard de alertas en frontend

---

## LECCIONES APRENDIDAS

1. **n8n Webhook**: Siempre configurar "Response Mode" = "Using 'Respond to Webhook' Node"
2. **Supabase Triggers**: Existen triggers que llaman a n8n cuando hay INSERT en properties y bookings
3. **Execute Once**: Activar en nodos n8n que no deben duplicar ejecución
4. **Constraints**: Verificar y eliminar constraints restrictivos antes de INSERT

---

## ARCHIVOS DE REFERENCIA

Los siguientes archivos contienen información detallada:
- `MYHOST_BizMate_Documentation_23Dec2025.md` - Documentación completa
- `MYHOST_BizMate_Schema_Definitivo.sql` - Esquema SQL de todas las tablas
- `MYHOST_Demo_Data_Setup.sql` - Script para crear datos de demo

---

## PREFERENCIAS DE TRABAJO

- Responder en **español**
- Proporcionar soluciones **completas y probadas**, no iterativas
- Documentar todo cambio realizado
- Hacer backup antes de operaciones destructivas
- Verificar estado actual antes de modificar

---

*Usa este prompt al inicio de cada nueva sesión para mantener contexto.*
