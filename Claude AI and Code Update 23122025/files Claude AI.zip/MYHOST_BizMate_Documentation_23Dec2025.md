# MY HOST BizMate - Documentación Completa del Proyecto
## Actualización: 23 Diciembre 2025 - 17:00 SGT

---

## 1. RESUMEN EJECUTIVO

**MY HOST BizMate** es una plataforma SaaS de gestión hotelera con automatización AI para boutique hotels y villas en el Sudeste Asiático, especialmente Bali.

### Cliente Piloto
- **Izumi Hotel**: Boutique hotel 5 estrellas en Ubud, Bali (apertura verano 2026)
- **7 tipos de habitación**: River Villa, Nest Villa, Cave Villa, 5BR Villa, Blossom Villa, Sky Villa, Tropical Room

### Stack Tecnológico
| Componente | Tecnología |
|------------|------------|
| Frontend | React + Tailwind CSS + Framer Motion (Vercel) |
| Backend/DB | Supabase (PostgreSQL) |
| Workflows | n8n (Railway) |
| AI | Claude API (Anthropic) |
| WhatsApp | ChakraHQ Business API |
| Voice | Vapi.ai (en desarrollo) |

---

## 2. ARQUITECTURA DE WORKFLOWS

### 2.1 Workflows Operativos (Externos)
| ID | Nombre | Estado | Trigger |
|----|--------|--------|---------|
| WF-Property | New Property Notification | ✅ Activo | Supabase INSERT trigger |
| WF-Booking | Booking Confirmation | ✅ Activo | Supabase INSERT trigger |
| WF-Vapi | Voice Assistant | 🔧 En desarrollo | Vapi.ai webhook |

### 2.2 Workflows de IA Interna (Owner Agent)
| ID | Nombre | Estado | Trigger | Función |
|----|--------|--------|---------|---------|
| WF1 | Owner Daily Intelligence | ✅ Activo | Cron 9AM SGT | KPIs diarios por WhatsApp |
| WF-IA-01 | Owner AI Assistant | ✅ Activo | Webhook POST | Chat interactivo con IA |
| WF-IA-02 | Owner AI Recommendation | ✅ Activo | Cron 8AM SGT | Alertas automáticas |
| WF-IA-03 | Action Executor | ⏳ Pendiente | Webhook | Ejecutar acciones sugeridas |

---

## 3. DETALLE DE WORKFLOWS COMPLETADOS

### 3.1 WF1 - Owner Daily Intelligence
**URL n8n**: `https://n8n-production-bb2d.up.railway.app/workflow/aergpRINvoJEyufR`
**Webhook**: `https://n8n-production-bb2d.up.railway.app/webhook/owner-daily-intelligence`

**Flujo**:
```
Schedule 9AM → Get Bookings → Calculate KPIs → Claude AI → Format → Save to DB → Send WhatsApp
```

**KPIs calculados**:
- Check-ins/check-outs hoy
- Huéspedes in-house
- Ocupación próximos 7 días
- Revenue próximos 7 días
- Cancelaciones últimos 7 días

**Configuración Schedule**: 9AM hora Singapur (Asia/Singapore)

---

### 3.2 WF-IA-01 - Owner AI Assistant
**URL n8n**: `https://n8n-production-bb2d.up.railway.app/workflow/iAMo7NdzYkJxJUkP`
**Webhook**: `https://n8n-production-bb2d.up.railway.app/webhook/owner-ai-assistant`

**Flujo**:
```
Webhook POST → Normalize → Get Properties → Get Bookings → Get Alerts → KPI Calculator → Claude AI → Format → Save History → Respond
```

**Configuración Webhook**:
- Method: POST
- Response Mode: "Using 'Respond to Webhook' Node" ⚠️ CRÍTICO
- Body esperado: `{"tenant_id": "uuid", "user_id": "uuid", "message": "texto"}`

**Test PowerShell**:
```powershell
$body = '{"tenant_id":"00000000-0000-0000-0000-000000000000","message":"Como va mi negocio"}'
Invoke-WebRequest -Method POST -Uri "https://n8n-production-bb2d.up.railway.app/webhook/owner-ai-assistant" -ContentType "application/json" -Body $body
```

---

### 3.3 WF-IA-02 - Owner AI Recommendation
**URL n8n**: `https://n8n-production-bb2d.up.railway.app/workflow/vDlWuAbhQkbut0Ei`

**Flujo**:
```
Cron 8AM → Set Tenant → Get Properties → Get Bookings → Rule Engine → IF Alerts? → Prepare → Insert Alerts → Log
```

**Reglas de Negocio**:
1. **Ocupación baja** (<40% próximos 7 días) → severity: high
2. **Sin reservas** (14 días) → severity: medium
3. **Cancelaciones altas** (≥3 en 7 días) → severity: high
4. **Check-ins pendientes** (hoy sin confirmar) → severity: high

---

## 4. ESQUEMA DE BASE DE DATOS

### 4.1 Tablas Principales (existentes)
- `properties` - Propiedades/villas
- `bookings` - Reservaciones
- `guests` - Huéspedes
- `payments` - Pagos
- `messages` - Mensajes WhatsApp
- `users` - Usuarios del sistema

### 4.2 Tablas de IA/Workflows (creadas)
```sql
-- Alertas del sistema de recomendaciones
alerts (id, tenant_id, alert_type, severity, title, description, status, property_id, ...)

-- Historial de chat con IA
ai_chat_history (id, tenant_id, user_id, message, answer, suggested_actions, ...)

-- Logs de recomendaciones
recommendation_logs (id, tenant_id, rule_triggered, alert_id, data_snapshot, ...)

-- Logs de workflows
workflow_logs (id, tenant_id, workflow_name, execution_status, execution_data, ...)

-- Logs de auditoría
audit_logs (id, tenant_id, action_type, payload_in, payload_out, ...)

-- Tareas operativas
ops_tasks (id, tenant_id, task_type, title, priority, status, property_id, ...)

-- Insights del propietario
owner_insights (id, tenant_id, date, payload_json, summary_text, ...)
```

### 4.3 Modificaciones Realizadas a Tablas
Las siguientes columnas fueron añadidas durante el desarrollo:

**alerts**:
- tenant_id, alert_type, title, description, property_id, resolved_at
- Eliminados constraints: alerts_severity_check, alerts_status_check
- message permitir NULL

**ai_chat_history**:
- tenant_id, user_id, answer, suggested_actions
- Eliminado FK user_id

**audit_logs**:
- tenant_id, action_type, payload_in, payload_out
- event permitir NULL

---

## 5. TRIGGERS DE SUPABASE

### 5.1 Trigger: New Property → n8n
```sql
-- Pendiente documentar - ejecutar query para ver triggers existentes
```

### 5.2 Trigger: New Booking → n8n
```sql
-- Pendiente documentar - ejecutar query para ver triggers existentes
```

---

## 6. CREDENCIALES Y CONFIGURACIÓN

### 6.1 IDs de Prueba
- **Tenant ID**: `00000000-0000-0000-0000-000000000000`
- **User ID**: `00000000-0000-0000-0000-000000000001`

### 6.2 n8n
- **URL Base**: `https://n8n-production-bb2d.up.railway.app`
- **Supabase Credential ID**: `SJLQzwU9BVHEVAGc`

### 6.3 APIs
- **Claude API**: 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
- **ChakraHQ**: Configurado en n8n credentials

### 6.4 Contacto Izumi Hotel
- WhatsApp: +62 813 2576 4867 (24/7)
- Web: www.my-host-bizmate.com

---

## 7. LECCIONES APRENDIDAS

### 7.1 n8n Webhook con Respond to Webhook
**Problema**: Error "Unused Respond to Webhook node found"
**Solución**: En el nodo Webhook, configurar "Response Mode" = "Using 'Respond to Webhook' Node"

### 7.2 Supabase Schema Cache
**Problema**: Errores de columnas no encontradas después de ALTER TABLE
**Solución**: Los cambios se reflejan inmediatamente, pero verificar con información_schema

### 7.3 n8n Execute Once
**Problema**: Nodos que procesan arrays duplican el flujo
**Solución**: Activar "Execute Once" en nodos que deben ejecutarse una sola vez

---

## 8. TAREAS PENDIENTES

### 8.1 Inmediatas
- [ ] Verificar triggers de Supabase existentes
- [ ] Limpiar datos de prueba en Supabase
- [ ] Crear datos de demo coherentes (Izumi Hotel + Villa Demo)
- [ ] Construir WF-IA-03 Action Executor

### 8.2 Corto Plazo
- [ ] Completar integración Vapi.ai
- [ ] Dashboard de alertas en frontend
- [ ] Sistema de notificaciones push

### 8.3 Documentación
- [ ] Documentar todos los triggers de Supabase
- [ ] Crear script SQL maestro con esquema completo
- [ ] Manual de usuario para propietarios

---

## 9. ARCHIVOS GENERADOS

| Archivo | Ubicación | Descripción |
|---------|-----------|-------------|
| MYHOST_BizMate_Schema_Definitivo.sql | /outputs | Esquema SQL completo |
| MYHOST_Demo_Data_Setup.sql | /outputs | Script de datos demo |
| WF-IA-01-Owner-AI-Assistant.json | /home/claude | JSON del workflow |
| WF-IA-02-Owner-AI-Recommendation.json | /home/claude | JSON del workflow |

---

## 10. HISTORIAL DE SESIONES

| Fecha | Transcript | Resumen |
|-------|------------|---------|
| 22 Dic | workflow1-owner-daily-intelligence-build | Construcción WF1 |
| 22 Dic | workflow1-owner-daily-intelligence-debugging | Debugging WF1 |
| 23 Dic | workflow1-final-testing | Testing exitoso WF1 |
| 23 Dic | wf-ia-02-recommendation-workflow-build | Construcción WF-IA-02 |
| 23 Dic | wf-ia-02-testing-wf-ia-01-build | Testing WF-IA-02 + Build WF-IA-01 |

---

*Documento generado: 23 Diciembre 2025, 17:00 SGT*
