# 📋 Instrucciones: Aplicar Backend Fase 1 a Supabase

## Método 1: SQL Editor (Recomendado)

### Paso 1: Acceder al SQL Editor
1. Ve a https://supabase.com/dashboard
2. Selecciona tu proyecto: **jjpscimtxrudtepzwhag**
3. En el menú lateral, haz click en **SQL Editor**

### Paso 2: Ejecutar el Script
1. Click en **New query**
2. Abre el archivo: `supabase_backups/COMPLETE_BACKEND_FASE1.sql`
3. Copia TODO el contenido del archivo
4. Pégalo en el SQL Editor
5. Click en **RUN** (o Ctrl/Cmd + Enter)

### Paso 3: Verificar Instalación
Ejecuta esta query para verificar:

```sql
-- Verificar funciones
SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'public'
AND routine_name LIKE 'notify_%' OR routine_name LIKE 'get_%';

-- Verificar triggers
SELECT trigger_name, event_object_table, action_timing, event_manipulation
FROM information_schema.triggers
WHERE trigger_schema = 'public';
```

Deberías ver:
- ✅ 5 funciones de notificación
- ✅ 3 funciones de estadísticas
- ✅ 8 triggers activos

---

## Método 2: psql CLI (Alternativo)

Si tienes psql instalado:

```bash
psql "postgresql://postgres:[YOUR-PASSWORD]@db.jjpscimtxrudtepzwhag.supabase.co:5432/postgres" -f supabase_backups/COMPLETE_BACKEND_FASE1.sql
```

**Password:** Encuéntrala en Settings → Database → Connection string

---

## ¿Qué se instala?

### 🔔 Triggers de Notificación (5)
| Trigger | Tabla | Evento | Webhook |
|---------|-------|--------|---------|
| `on_property_insert` | properties | INSERT | /webhook/property-created |
| `on_booking_insert` | bookings | INSERT | /webhook/booking-created |
| `on_booking_status_update` | bookings | UPDATE | /webhook/booking-status-changed |
| `on_payment_update` | payments | INSERT/UPDATE | /webhook/payment-confirmed |
| `on_message_insert` | messages | INSERT | /webhook/message-received |

### 📊 Funciones de Estadísticas (3)
| Función | Descripción | Uso |
|---------|-------------|-----|
| `get_dashboard_stats()` | Estadísticas generales | Dashboard principal |
| `get_revenue_by_month(months)` | Ingresos por mes | Gráficos de ingresos |
| `get_top_properties(limit)` | Top propiedades | Rankings |

### 🔒 RLS Policies
- ✅ properties: Lectura pública, escritura autenticada
- ✅ bookings: Solo propietarios pueden gestionar
- ✅ payments: Solo propietarios ven sus pagos
- ✅ messages: Basado en propiedad

### ⚡ Optimización
- ✅ 15 índices creados para mejorar velocidad
- ✅ Actualización automática de `updated_at`

---

## Problemas Comunes

### Error: "extension pg_net does not exist"
**Solución:**
1. Ve a Database → Extensions
2. Busca "pg_net"
3. Click en "Enable"

### Error: "permission denied"
**Causa:** Usuario no tiene permisos suficientes
**Solución:** Asegúrate de estar usando service_role key o postgres user

### Error: "trigger already exists"
**Causa:** Triggers ya instalados previamente
**Solución:** El script incluye `DROP TRIGGER IF EXISTS`, debería funcionar. Si no, ejecuta manualmente:
```sql
DROP TRIGGER IF EXISTS on_property_insert ON properties CASCADE;
```

---

## Próximos Pasos

Una vez aplicado el SQL:

1. ✅ **Probar triggers** - Insertar una propiedad de prueba
2. ✅ **Configurar n8n** - Crear webhooks correspondientes
3. ✅ **Actualizar frontend** - Usar las nuevas funciones de estadísticas
4. ✅ **Monitorear** - Revisar logs de webhooks

---

## Soporte

Si encuentras problemas:
1. Revisa los logs de Supabase: Database → Logs
2. Verifica pg_net: `SELECT * FROM net._http_response ORDER BY created DESC LIMIT 10;`
3. Consulta la documentación: https://supabase.com/docs

