-- ================================================
-- MY HOST BizMate - BACKEND FASE 1 COMPLETO
-- ================================================
-- Date: 2025-11-27
-- Description: Triggers, funciones y RLS policies completas
-- ================================================

-- ================================================
-- EXTENSIONES NECESARIAS
-- ================================================

CREATE EXTENSION IF NOT EXISTS pg_net;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ================================================
-- FUNCIONES PARA WEBHOOKS N8N
-- ================================================

-- Función 1: Notificar nueva propiedad
CREATE OR REPLACE FUNCTION notify_property_registered()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://n8n-production-bb2d.up.railway.app/webhook/property-created',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object(
      'event', 'property_created',
      'id', NEW.id,
      'name', NEW.name,
      'location', NEW.location,
      'type', NEW.type,
      'beds', NEW.beds,
      'baths', NEW.baths,
      'base_price', NEW.base_price,
      'status', NEW.status,
      'created_at', NEW.created_at
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función 2: Notificar nueva reserva (booking)
CREATE OR REPLACE FUNCTION notify_booking_created()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-created',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object(
      'event', 'booking_created',
      'id', NEW.id,
      'property_id', NEW.property_id,
      'guest_name', NEW.guest_name,
      'guest_email', NEW.guest_email,
      'guest_phone', NEW.guest_phone,
      'check_in', NEW.check_in,
      'check_out', NEW.check_out,
      'guests_count', NEW.guests_count,
      'total_amount', NEW.total_amount,
      'status', NEW.status,
      'booking_source', NEW.booking_source,
      'confirmation_code', NEW.confirmation_code,
      'created_at', NEW.created_at
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función 3: Notificar cambio de estado de reserva
CREATE OR REPLACE FUNCTION notify_booking_status_changed()
RETURNS TRIGGER AS $$
BEGIN
  -- Solo notificar si el status cambió
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM net.http_post(
      url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-status-changed',
      headers := '{"Content-Type": "application/json"}'::jsonb,
      body := jsonb_build_object(
        'event', 'booking_status_changed',
        'id', NEW.id,
        'old_status', OLD.status,
        'new_status', NEW.status,
        'guest_name', NEW.guest_name,
        'guest_email', NEW.guest_email,
        'confirmation_code', NEW.confirmation_code,
        'updated_at', NEW.updated_at
      )
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función 4: Notificar pago confirmado
CREATE OR REPLACE FUNCTION notify_payment_confirmed()
RETURNS TRIGGER AS $$
BEGIN
  -- Solo notificar si el pago fue confirmado
  IF NEW.status = 'paid' AND (OLD.status IS NULL OR OLD.status != 'paid') THEN
    PERFORM net.http_post(
      url := 'https://n8n-production-bb2d.up.railway.app/webhook/payment-confirmed',
      headers := '{"Content-Type": "application/json"}'::jsonb,
      body := jsonb_build_object(
        'event', 'payment_confirmed',
        'id', NEW.id,
        'booking_id', NEW.booking_id,
        'amount', NEW.amount,
        'currency', NEW.currency,
        'payment_method', NEW.payment_method,
        'stripe_payment_id', NEW.stripe_payment_id,
        'paid_at', NEW.paid_at,
        'created_at', NEW.created_at
      )
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función 5: Notificar nuevo mensaje
CREATE OR REPLACE FUNCTION notify_message_received()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://n8n-production-bb2d.up.railway.app/webhook/message-received',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object(
      'event', 'message_received',
      'id', NEW.id,
      'booking_id', NEW.booking_id,
      'sender_type', NEW.sender_type,
      'sender_name', NEW.sender_name,
      'sender_email', NEW.sender_email,
      'message', NEW.message,
      'is_automated', NEW.is_automated,
      'created_at', NEW.created_at
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ================================================
-- TRIGGERS
-- ================================================

-- Trigger 1: Nueva propiedad
DROP TRIGGER IF EXISTS on_property_insert ON properties;
CREATE TRIGGER on_property_insert
  AFTER INSERT ON properties
  FOR EACH ROW
  EXECUTE FUNCTION notify_property_registered();

-- Trigger 2: Nueva reserva
DROP TRIGGER IF EXISTS on_booking_insert ON bookings;
CREATE TRIGGER on_booking_insert
  AFTER INSERT ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION notify_booking_created();

-- Trigger 3: Cambio de estado de reserva
DROP TRIGGER IF EXISTS on_booking_status_update ON bookings;
CREATE TRIGGER on_booking_status_update
  AFTER UPDATE ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION notify_booking_status_changed();

-- Trigger 4: Pago confirmado
DROP TRIGGER IF EXISTS on_payment_update ON payments;
CREATE TRIGGER on_payment_update
  AFTER INSERT OR UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION notify_payment_confirmed();

-- Trigger 5: Nuevo mensaje
DROP TRIGGER IF EXISTS on_message_insert ON messages;
CREATE TRIGGER on_message_insert
  AFTER INSERT ON messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_message_received();

-- ================================================
-- FUNCIONES PARA ESTADÍSTICAS Y DASHBOARD
-- ================================================

-- Función: Obtener estadísticas generales del dashboard
CREATE OR REPLACE FUNCTION get_dashboard_stats()
RETURNS TABLE(
  total_properties BIGINT,
  total_bookings BIGINT,
  total_revenue NUMERIC,
  avg_occupancy NUMERIC,
  active_bookings BIGINT,
  pending_payments BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM properties WHERE status = 'active'),
    (SELECT COUNT(*) FROM bookings),
    (SELECT COALESCE(SUM(total_amount), 0) FROM bookings WHERE status = 'confirmed'),
    (SELECT ROUND(
      (COUNT(*) FILTER (WHERE status = 'confirmed')::NUMERIC / NULLIF(COUNT(*), 0)) * 100, 2
    ) FROM bookings),
    (SELECT COUNT(*) FROM bookings WHERE status IN ('confirmed', 'checked_in')),
    (SELECT COUNT(*) FROM payments WHERE status = 'pending');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función: Obtener ingresos por mes
CREATE OR REPLACE FUNCTION get_revenue_by_month(months_back INTEGER DEFAULT 12)
RETURNS TABLE(
  month TEXT,
  revenue NUMERIC,
  bookings_count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    TO_CHAR(DATE_TRUNC('month', created_at), 'YYYY-MM') as month,
    COALESCE(SUM(total_amount), 0) as revenue,
    COUNT(*) as bookings_count
  FROM bookings
  WHERE created_at >= NOW() - (months_back || ' months')::INTERVAL
    AND status = 'confirmed'
  GROUP BY DATE_TRUNC('month', created_at)
  ORDER BY month DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función: Obtener top propiedades por ingresos
CREATE OR REPLACE FUNCTION get_top_properties(limit_count INTEGER DEFAULT 10)
RETURNS TABLE(
  property_id UUID,
  property_name TEXT,
  total_bookings BIGINT,
  total_revenue NUMERIC,
  avg_rating NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    p.id,
    p.name,
    COUNT(b.id) as total_bookings,
    COALESCE(SUM(b.total_amount), 0) as total_revenue,
    p.rating
  FROM properties p
  LEFT JOIN bookings b ON p.id = b.property_id
  WHERE p.status = 'active'
  GROUP BY p.id, p.name, p.rating
  ORDER BY total_revenue DESC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función: Actualizar timestamp de updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger de updated_at a todas las tablas
DROP TRIGGER IF EXISTS update_properties_updated_at ON properties;
CREATE TRIGGER update_properties_updated_at
  BEFORE UPDATE ON properties
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_bookings_updated_at ON bookings;
CREATE TRIGGER update_bookings_updated_at
  BEFORE UPDATE ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_payments_updated_at ON payments;
CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ================================================

-- Habilitar RLS en todas las tablas
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE guests ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Política: Permitir lectura pública de propiedades activas
CREATE POLICY "Public properties are viewable by everyone"
  ON properties FOR SELECT
  USING (status = 'active');

-- Política: Solo usuarios autenticados pueden insertar propiedades
CREATE POLICY "Authenticated users can insert properties"
  ON properties FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Política: Solo el dueño puede actualizar su propiedad
CREATE POLICY "Users can update own properties"
  ON properties FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Política: Solo el dueño puede eliminar su propiedad
CREATE POLICY "Users can delete own properties"
  ON properties FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

-- Política: Usuarios autenticados pueden ver todas las reservas
CREATE POLICY "Authenticated users can view bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (true);

-- Política: Usuarios autenticados pueden crear reservas
CREATE POLICY "Authenticated users can insert bookings"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Política: Solo propietarios pueden actualizar reservas
CREATE POLICY "Property owners can update bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (
    property_id IN (
      SELECT id FROM properties WHERE owner_id = auth.uid()
    )
  );

-- Política: Ver pagos de propiedades propias
CREATE POLICY "Users can view own payments"
  ON payments FOR SELECT
  TO authenticated
  USING (
    booking_id IN (
      SELECT b.id FROM bookings b
      JOIN properties p ON b.property_id = p.id
      WHERE p.owner_id = auth.uid()
    )
  );

-- Política: Insertar pagos (sistema)
CREATE POLICY "System can insert payments"
  ON payments FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Política: Ver mensajes de propiedades propias
CREATE POLICY "Users can view own messages"
  ON messages FOR SELECT
  TO authenticated
  USING (
    booking_id IN (
      SELECT b.id FROM bookings b
      JOIN properties p ON b.property_id = p.id
      WHERE p.owner_id = auth.uid()
    )
  );

-- Política: Insertar mensajes
CREATE POLICY "Authenticated users can insert messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- ================================================
-- ÍNDICES PARA OPTIMIZACIÓN
-- ================================================

-- Índices para propiedades
CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_owner_id ON properties(owner_id);
CREATE INDEX IF NOT EXISTS idx_properties_type ON properties(type);
CREATE INDEX IF NOT EXISTS idx_properties_location ON properties(location);

-- Índices para bookings
CREATE INDEX IF NOT EXISTS idx_bookings_property_id ON bookings(property_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_check_in ON bookings(check_in);
CREATE INDEX IF NOT EXISTS idx_bookings_check_out ON bookings(check_out);
CREATE INDEX IF NOT EXISTS idx_bookings_guest_email ON bookings(guest_email);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON bookings(created_at);

-- Índices para payments
CREATE INDEX IF NOT EXISTS idx_payments_booking_id ON payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_paid_at ON payments(paid_at);

-- Índices para messages
CREATE INDEX IF NOT EXISTS idx_messages_booking_id ON messages(booking_id);
CREATE INDEX IF NOT EXISTS idx_messages_is_read ON messages(is_read);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- ================================================
-- GRANTS Y PERMISOS
-- ================================================

-- Permitir a usuarios autenticados ejecutar funciones
GRANT EXECUTE ON FUNCTION get_dashboard_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION get_revenue_by_month(INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION get_top_properties(INTEGER) TO authenticated;

-- ================================================
-- COMENTARIOS EN TABLAS Y FUNCIONES
-- ================================================

COMMENT ON FUNCTION notify_property_registered() IS 'Envía notificación a n8n cuando se registra una propiedad';
COMMENT ON FUNCTION notify_booking_created() IS 'Envía notificación a n8n cuando se crea una reserva';
COMMENT ON FUNCTION notify_booking_status_changed() IS 'Envía notificación a n8n cuando cambia el estado de una reserva';
COMMENT ON FUNCTION notify_payment_confirmed() IS 'Envía notificación a n8n cuando se confirma un pago';
COMMENT ON FUNCTION notify_message_received() IS 'Envía notificación a n8n cuando se recibe un mensaje';
COMMENT ON FUNCTION get_dashboard_stats() IS 'Obtiene estadísticas generales para el dashboard';
COMMENT ON FUNCTION get_revenue_by_month(INTEGER) IS 'Obtiene ingresos agrupados por mes';
COMMENT ON FUNCTION get_top_properties(INTEGER) IS 'Obtiene las propiedades con más ingresos';

-- ================================================
-- FIN DEL SCRIPT
-- ================================================

-- Para verificar que todo se instaló correctamente:
SELECT 'Backend Fase 1 - Instalación completada!' as status;
