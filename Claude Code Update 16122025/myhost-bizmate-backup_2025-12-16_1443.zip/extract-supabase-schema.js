import { createClient } from '@supabase/supabase-js';
import { writeFileSync } from 'fs';

const supabaseUrl = 'https://jjpscimtxrudtepzwhag.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpqcHNjaW10eHJ1ZHRlcHp3aGFnIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2Mjk0MzIzMiwiZXhwIjoyMDc4NTE5MjMyfQ.RBD16xjgQB__nj5DtLrK2w55uQ4WFJiaa0mfZT2BeJg';

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function extractSchema() {
  try {
    console.log('🔍 Conectando a Supabase con service_role key...\n');

    // 1. Obtener todas las tablas
    console.log('📋 Extrayendo lista de tablas...');
    const { data: tables, error: tablesError } = await supabase
      .rpc('exec_sql', {
        query: `
          SELECT table_name
          FROM information_schema.tables
          WHERE table_schema = 'public'
          AND table_type = 'BASE TABLE'
          ORDER BY table_name;
        `
      });

    if (tablesError) {
      // Intentar método alternativo usando postgrest
      console.log('⚠️  Intentando método alternativo...');

      // Listar tablas manualmente haciendo query a cada una
      const knownTables = ['properties', 'bookings', 'guests', 'payments', 'messages'];
      let foundTables = [];

      for (const table of knownTables) {
        const { error } = await supabase.from(table).select('*').limit(1);
        if (!error) {
          foundTables.push(table);
          console.log(`  ✅ ${table}`);
        }
      }

      if (foundTables.length === 0) {
        console.error('❌ No se pudieron encontrar tablas');
        return;
      }

      // Generar script SQL para cada tabla encontrada
      let fullSQL = `-- ================================================\n`;
      fullSQL += `-- BACKUP SUPABASE SCHEMA - MY HOST BizMate\n`;
      fullSQL += `-- Date: ${new Date().toISOString()}\n`;
      fullSQL += `-- Project: jjpscimtxrudtepzwhag\n`;
      fullSQL += `-- ================================================\n\n`;

      for (const table of foundTables) {
        console.log(`\n📊 Extrayendo estructura de tabla: ${table}`);

        const { data, error } = await supabase.from(table).select('*').limit(1);

        if (!error && data && data.length > 0) {
          fullSQL += `-- Table: ${table}\n`;
          fullSQL += `-- Columns detected:\n`;
          Object.keys(data[0]).forEach(col => {
            fullSQL += `--   - ${col}\n`;
          });
          fullSQL += `\n`;
        }
      }

      // Agregar triggers conocidos del backup
      fullSQL += `\n-- ================================================\n`;
      fullSQL += `-- TRIGGERS Y FUNCIONES\n`;
      fullSQL += `-- ================================================\n\n`;

      fullSQL += `-- Extension requerida\n`;
      fullSQL += `CREATE EXTENSION IF NOT EXISTS pg_net;\n\n`;

      fullSQL += `-- Función para notificación de propiedades\n`;
      fullSQL += `CREATE OR REPLACE FUNCTION notify_property_registered()\n`;
      fullSQL += `RETURNS TRIGGER AS $$\n`;
      fullSQL += `BEGIN\n`;
      fullSQL += `  PERFORM net.http_post(\n`;
      fullSQL += `    url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-created',\n`;
      fullSQL += `    headers := '{"Content-Type": "application/json"}'::jsonb,\n`;
      fullSQL += `    body := jsonb_build_object(\n`;
      fullSQL += `      'id', NEW.id,\n`;
      fullSQL += `      'name', NEW.name,\n`;
      fullSQL += `      'location', NEW.location,\n`;
      fullSQL += `      'type', NEW.type,\n`;
      fullSQL += `      'beds', NEW.beds,\n`;
      fullSQL += `      'baths', NEW.baths,\n`;
      fullSQL += `      'base_price', NEW.base_price,\n`;
      fullSQL += `      'created_at', NEW.created_at\n`;
      fullSQL += `    )\n`;
      fullSQL += `  );\n`;
      fullSQL += `  RETURN NEW;\n`;
      fullSQL += `END;\n`;
      fullSQL += `$$ LANGUAGE plpgsql SECURITY DEFINER;\n\n`;

      fullSQL += `-- Trigger para propiedades\n`;
      fullSQL += `DROP TRIGGER IF EXISTS on_property_insert ON properties;\n`;
      fullSQL += `CREATE TRIGGER on_property_insert\n`;
      fullSQL += `  AFTER INSERT ON properties\n`;
      fullSQL += `  FOR EACH ROW\n`;
      fullSQL += `  EXECUTE FUNCTION notify_property_registered();\n\n`;

      // Guardar archivo
      const filename = `supabase_backup_${Date.now()}.sql`;
      writeFileSync(filename, fullSQL);

      console.log(`\n✅ Backup creado: ${filename}`);
      console.log(`📁 Tablas encontradas: ${foundTables.join(', ')}`);

      return;
    }

    console.log('✅ Tablas extraídas:', tables);

  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error(error);
  }
}

extractSchema();
