-- CLEANUP - Borrar todo lo que pueda estar a medias
-- Ejecutar ESTE primero, luego el COMPLETE_BACKEND_FASE1_FIXED.sql

-- Borrar policies
DROP POLICY IF EXISTS "Public properties are viewable by everyone" ON properties;
DROP POLICY IF EXISTS "Authenticated users can insert properties" ON properties;
DROP POLICY IF EXISTS "Users can update own properties" ON properties;
DROP POLICY IF EXISTS "Users can delete own properties" ON properties;
DROP POLICY IF EXISTS "Authenticated users can view bookings" ON bookings;
DROP POLICY IF EXISTS "Authenticated users can insert bookings" ON bookings;
DROP POLICY IF EXISTS "Property owners can update bookings" ON bookings;
DROP POLICY IF EXISTS "Users can view own payments" ON payments;
DROP POLICY IF EXISTS "System can insert payments" ON payments;
DROP POLICY IF EXISTS "Users can view own messages" ON messages;
DROP POLICY IF EXISTS "Authenticated users can insert messages" ON messages;

-- Borrar triggers
DROP TRIGGER IF EXISTS on_property_insert ON properties;
DROP TRIGGER IF EXISTS on_booking_insert ON bookings;
DROP TRIGGER IF EXISTS on_booking_status_update ON bookings;
DROP TRIGGER IF EXISTS on_payment_update ON payments;
DROP TRIGGER IF EXISTS on_message_insert ON messages;
DROP TRIGGER IF EXISTS update_properties_updated_at ON properties;
DROP TRIGGER IF EXISTS update_bookings_updated_at ON bookings;
DROP TRIGGER IF EXISTS update_payments_updated_at ON payments;

-- Borrar funciones
DROP FUNCTION IF EXISTS notify_property_registered() CASCADE;
DROP FUNCTION IF EXISTS notify_booking_created() CASCADE;
DROP FUNCTION IF EXISTS notify_booking_status_changed() CASCADE;
DROP FUNCTION IF EXISTS notify_payment_confirmed() CASCADE;
DROP FUNCTION IF EXISTS notify_message_received() CASCADE;
DROP FUNCTION IF EXISTS get_dashboard_stats() CASCADE;
DROP FUNCTION IF EXISTS get_revenue_by_month(INTEGER) CASCADE;
DROP FUNCTION IF EXISTS get_top_properties(INTEGER) CASCADE;
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

SELECT 'Cleanup completado - Ahora ejecuta COMPLETE_BACKEND_FASE1_FIXED.sql' as status;
