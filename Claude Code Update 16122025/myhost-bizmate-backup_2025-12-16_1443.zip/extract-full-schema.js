import { createClient } from '@supabase/supabase-js';
import { writeFileSync } from 'fs';

const supabaseUrl = 'https://jjpscimtxrudtepzwhag.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpqcHNjaW10eHJ1ZHRlcHp3aGFnIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2Mjk0MzIzMiwiZXhwIjoyMDc4NTE5MjMyfQ.RBD16xjgQB__nj5DtLrK2w55uQ4WFJiaa0mfZT2BeJg';

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  db: { schema: 'public' }
});

async function getTableSchema(tableName) {
  try {
    // Consultar un registro para ver la estructura
    const { data, error } = await supabase
      .from(tableName)
      .select('*')
      .limit(1);

    if (error) {
      console.log(`   ⚠️  No se pudo consultar ${tableName}: ${error.message}`);
      return null;
    }

    if (!data || data.length === 0) {
      console.log(`   ℹ️  Tabla ${tableName} está vacía, consultando estructura...`);
      // Tabla vacía, pero existe
      return { columns: [] };
    }

    const columns = Object.keys(data[0]);
    const sample = data[0];

    return {
      columns,
      sample,
      types: Object.fromEntries(
        columns.map(col => [col, typeof sample[col]])
      )
    };

  } catch (err) {
    console.log(`   ❌ Error consultando ${tableName}:`, err.message);
    return null;
  }
}

async function extractFullSchema() {
  console.log('🔍 Extrayendo esquema completo de Supabase...\n');

  const tables = ['properties', 'bookings', 'guests', 'payments', 'messages'];
  const schemas = {};

  for (const table of tables) {
    console.log(`📊 Procesando: ${table}`);
    const schema = await getTableSchema(table);
    if (schema) {
      schemas[table] = schema;
      console.log(`   ✅ ${schema.columns.length} columnas detectadas`);
    }
  }

  // Generar SQL completo
  let sql = `-- ================================================\n`;
  sql += `-- BACKUP COMPLETO SUPABASE - MY HOST BizMate\n`;
  sql += `-- Date: ${new Date().toISOString()}\n`;
  sql += `-- Project: jjpscimtxrudtepzwhag\n`;
  sql += `-- URL: ${supabaseUrl}\n`;
  sql += `-- ================================================\n\n`;

  // Tablas
  for (const [tableName, schema] of Object.entries(schemas)) {
    sql += `\n-- ================================================\n`;
    sql += `-- TABLE: ${tableName}\n`;
    sql += `-- ================================================\n\n`;

    if (schema.columns.length === 0) {
      sql += `-- Tabla vacía o sin acceso\n\n`;
      continue;
    }

    sql += `-- CREATE TABLE ${tableName} (\n`;
    schema.columns.forEach((col, idx) => {
      const jsType = schema.types[col];
      let sqlType = 'TEXT';

      // Inferir tipo SQL basado en nombre y tipo JS
      if (col.includes('_at')) sqlType = 'TIMESTAMPTZ DEFAULT NOW()';
      else if (col === 'id') sqlType = 'UUID PRIMARY KEY DEFAULT gen_random_uuid()';
      else if (col.includes('_id')) sqlType = 'UUID REFERENCES ...';
      else if (col === 'email') sqlType = 'TEXT';
      else if (col.includes('amount') || col.includes('price')) sqlType = 'DECIMAL(10,2)';
      else if (col.includes('count') || col === 'beds' || col === 'baths' || col === 'max_guests') sqlType = 'INTEGER';
      else if (col === 'rating') sqlType = 'DECIMAL(3,2)';
      else if (col.includes('is_')) sqlType = 'BOOLEAN DEFAULT FALSE';
      else if (jsType === 'object') sqlType = 'JSONB';

      sql += `--   ${col.padEnd(25)} ${sqlType}`;
      if (idx < schema.columns.length - 1) sql += ',';
      sql += `\n`;
    });
    sql += `-- );\n\n`;

    // Datos de ejemplo si existen
    if (schema.sample) {
      sql += `-- Ejemplo de datos:\n`;
      sql += `-- ${JSON.stringify(schema.sample, null, 2).split('\n').join('\n-- ')}\n\n`;
    }
  }

  // Triggers y funciones conocidos
  sql += `\n-- ================================================\n`;
  sql += `-- EXTENSIONS\n`;
  sql += `-- ================================================\n\n`;
  sql += `CREATE EXTENSION IF NOT EXISTS pg_net;\n`;
  sql += `CREATE EXTENSION IF NOT EXISTS "uuid-ossp";\n\n`;

  sql += `\n-- ================================================\n`;
  sql += `-- FUNCTIONS\n`;
  sql += `-- ================================================\n\n`;

  sql += `-- Función: notify_property_registered\n`;
  sql += `CREATE OR REPLACE FUNCTION notify_property_registered()\n`;
  sql += `RETURNS TRIGGER AS $$\n`;
  sql += `BEGIN\n`;
  sql += `  PERFORM net.http_post(\n`;
  sql += `    url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-created',\n`;
  sql += `    headers := '{"Content-Type": "application/json"}'::jsonb,\n`;
  sql += `    body := jsonb_build_object(\n`;
  sql += `      'id', NEW.id,\n`;
  sql += `      'name', NEW.name,\n`;
  sql += `      'location', NEW.location,\n`;
  sql += `      'type', NEW.type,\n`;
  sql += `      'beds', NEW.beds,\n`;
  sql += `      'baths', NEW.baths,\n`;
  sql += `      'base_price', NEW.base_price,\n`;
  sql += `      'created_at', NEW.created_at\n`;
  sql += `    )\n`;
  sql += `  );\n`;
  sql += `  RETURN NEW;\n`;
  sql += `END;\n`;
  sql += `$$ LANGUAGE plpgsql SECURITY DEFINER;\n\n`;

  sql += `\n-- ================================================\n`;
  sql += `-- TRIGGERS\n`;
  sql += `-- ================================================\n\n`;

  sql += `-- Trigger: on_property_insert\n`;
  sql += `DROP TRIGGER IF EXISTS on_property_insert ON properties;\n`;
  sql += `CREATE TRIGGER on_property_insert\n`;
  sql += `  AFTER INSERT ON properties\n`;
  sql += `  FOR EACH ROW\n`;
  sql += `  EXECUTE FUNCTION notify_property_registered();\n\n`;

  // Guardar archivo
  const filename = `SUPABASE_FULL_BACKUP_${new Date().toISOString().split('T')[0]}.sql`;
  writeFileSync(filename, sql);

  console.log(`\n✅ Backup completo creado: ${filename}`);
  console.log(`📊 Total tablas: ${Object.keys(schemas).length}`);
  console.log(`📁 Ubicación: ${process.cwd()}\\${filename}`);

  // Crear también un archivo JSON con la estructura
  const jsonFilename = `supabase_schema_${new Date().toISOString().split('T')[0]}.json`;
  writeFileSync(jsonFilename, JSON.stringify(schemas, null, 2));
  console.log(`📄 Schema JSON: ${jsonFilename}`);
}

extractFullSchema();