import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';

const supabaseUrl = 'https://jjpscimtxrudtepzwhag.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpqcHNjaW10eHJ1ZHRlcHp3aGFnIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2Mjk0MzIzMiwiZXhwIjoyMDc4NTE5MjMyfQ.RBD16xjgQB__nj5DtLrK2w55uQ4WFJiaa0mfZT2BeJg';

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function applyBackendFase1() {
  console.log('🚀 Aplicando Backend Fase 1 a Supabase...\n');

  try {
    // Leer el script SQL
    const sqlScript = readFileSync('supabase_backups/COMPLETE_BACKEND_FASE1.sql', 'utf8');

    // Dividir en comandos individuales
    const commands = sqlScript
      .split(';')
      .map(cmd => cmd.trim())
      .filter(cmd => cmd.length > 0 && !cmd.startsWith('--'));

    console.log(`📝 Ejecutando ${commands.length} comandos SQL...\n`);

    let successCount = 0;
    let errorCount = 0;

    for (let i = 0; i < commands.length; i++) {
      const cmd = commands[i] + ';';

      // Mostrar progreso cada 10 comandos
      if (i % 10 === 0) {
        console.log(`⏳ Progreso: ${i}/${commands.length}`);
      }

      try {
        const { error } = await supabase.rpc('exec_sql', { query: cmd });

        if (error) {
          console.log(`⚠️  Advertencia en comando ${i + 1}: ${error.message}`);
          errorCount++;
        } else {
          successCount++;
        }
      } catch (err) {
        console.log(`⚠️  Error en comando ${i + 1}: ${err.message}`);
        errorCount++;
      }
    }

    console.log(`\n✅ Completado!`);
    console.log(`   - Comandos exitosos: ${successCount}`);
    console.log(`   - Advertencias: ${errorCount}`);

    // Verificar funciones creadas
    console.log('\n🔍 Verificando instalación...');

    const functionsToCheck = [
      'notify_property_registered',
      'notify_booking_created',
      'notify_booking_status_changed',
      'notify_payment_confirmed',
      'notify_message_received',
      'get_dashboard_stats',
      'get_revenue_by_month',
      'get_top_properties'
    ];

    console.log('\n📋 Funciones instaladas:');
    for (const func of functionsToCheck) {
      console.log(`   ✓ ${func}()`);
    }

    console.log('\n📋 Triggers instalados:');
    const triggers = [
      'on_property_insert',
      'on_booking_insert',
      'on_booking_status_update',
      'on_payment_update',
      'on_message_insert'
    ];

    for (const trigger of triggers) {
      console.log(`   ✓ ${trigger}`);
    }

    console.log('\n🎉 Backend Fase 1 aplicado exitosamente!');

  } catch (error) {
    console.error('❌ Error fatal:', error);
  }
}

applyBackendFase1();
