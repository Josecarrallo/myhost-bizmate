-- ================================================
-- BACKUP COMPLETO SUPABASE - MY HOST BizMate
-- Date: 2025-11-27T08:30:30.589Z
-- Project: jjpscimtxrudtepzwhag
-- URL: https://jjpscimtxrudtepzwhag.supabase.co
-- ================================================


-- ================================================
-- TABLE: properties
-- ================================================

-- CREATE TABLE properties (
--   id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
--   user_id                   UUID REFERENCES ...,
--   name                      TEXT,
--   location                  TEXT,
--   type                      TEXT,
--   description               TEXT,
--   beds                      INTEGER,
--   baths                     INTEGER,
--   max_guests                INTEGER,
--   base_price                DECIMAL(10,2),
--   currency                  TEXT,
--   images                    JSONB,
--   amenities                 JSONB,
--   status                    TEXT,
--   rating                    DECIMAL(3,2),
--   address                   JSONB,
--   city                      TEXT,
--   country                   INTEGER,
--   created_at                TIMESTAMPTZ DEFAULT NOW(),
--   updated_at                TIMESTAMPTZ DEFAULT NOW()
-- );

-- Ejemplo de datos:
-- {
--   "id": "26836f5e-f2d6-4e61-b802-c39e1f2502f3",
--   "user_id": null,
--   "name": "Villa Sunset Paradise",
--   "location": "Bali, Indonesia",
--   "type": "villa",
--   "description": "Luxurious 5-bedroom villa with ocean views, infinity pool, and private beach access",
--   "beds": 5,
--   "baths": 4,
--   "max_guests": 10,
--   "base_price": 450,
--   "currency": "USD",
--   "images": [
--     "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800"
--   ],
--   "amenities": [
--     "Pool",
--     "WiFi",
--     "Kitchen",
--     "Beach Access",
--     "Air Conditioning"
--   ],
--   "status": "active",
--   "rating": 4.9,
--   "address": null,
--   "city": "Seminyak",
--   "country": "Indonesia",
--   "created_at": "2025-11-12T10:50:00.355031+00:00",
--   "updated_at": "2025-11-12T10:50:00.355031+00:00"
-- }


-- ================================================
-- TABLE: bookings
-- ================================================

-- CREATE TABLE bookings (
--   id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
--   property_id               UUID REFERENCES ...,
--   guest_name                TEXT,
--   guest_email               TEXT,
--   guest_phone               JSONB,
--   check_in                  TEXT,
--   check_out                 TEXT,
--   guests_count              INTEGER,
--   total_amount              DECIMAL(10,2),
--   status                    TEXT,
--   booking_source            TEXT,
--   special_requests          JSONB,
--   confirmation_code         TEXT,
--   created_at                TIMESTAMPTZ DEFAULT NOW(),
--   updated_at                TIMESTAMPTZ DEFAULT NOW()
-- );

-- Ejemplo de datos:
-- {
--   "id": "7387be9a-c571-406b-b767-ec6e206540bc",
--   "property_id": "0c4bf9a5-537b-47a9-9de2-f5f32f07fa21",
--   "guest_name": "Sarah Johnson",
--   "guest_email": "sarah.j@example.com",
--   "guest_phone": null,
--   "check_in": "2025-11-15",
--   "check_out": "2025-11-20",
--   "guests_count": 4,
--   "total_amount": 2250,
--   "status": "confirmed",
--   "booking_source": "direct",
--   "special_requests": null,
--   "confirmation_code": "BK-838D0B53",
--   "created_at": "2025-11-12T10:50:00.355031+00:00",
--   "updated_at": "2025-11-17T10:33:24.803657+00:00"
-- }


-- ================================================
-- TABLE: guests
-- ================================================

-- Tabla vacía o sin acceso


-- ================================================
-- TABLE: payments
-- ================================================

-- CREATE TABLE payments (
--   id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
--   booking_id                UUID REFERENCES ...,
--   amount                    DECIMAL(10,2),
--   currency                  TEXT,
--   status                    TEXT,
--   payment_method            TEXT,
--   stripe_payment_id         UUID REFERENCES ...,
--   stripe_payment_intent_id  UUID REFERENCES ...,
--   paid_at                   TIMESTAMPTZ DEFAULT NOW(),
--   refunded_at               TIMESTAMPTZ DEFAULT NOW(),
--   notes                     JSONB,
--   created_at                TIMESTAMPTZ DEFAULT NOW(),
--   updated_at                TIMESTAMPTZ DEFAULT NOW()
-- );

-- Ejemplo de datos:
-- {
--   "id": "e1abdc7a-7dd2-4943-b0ad-43e3df263101",
--   "booking_id": "7387be9a-c571-406b-b767-ec6e206540bc",
--   "amount": 2250,
--   "currency": "USD",
--   "status": "paid",
--   "payment_method": "stripe",
--   "stripe_payment_id": null,
--   "stripe_payment_intent_id": null,
--   "paid_at": "2025-11-12T10:50:00.355031+00:00",
--   "refunded_at": null,
--   "notes": null,
--   "created_at": "2025-11-12T10:50:00.355031+00:00",
--   "updated_at": "2025-11-12T10:50:00.355031+00:00"
-- }


-- ================================================
-- TABLE: messages
-- ================================================

-- CREATE TABLE messages (
--   id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
--   booking_id                UUID REFERENCES ...,
--   sender_type               TEXT,
--   sender_name               TEXT,
--   sender_email              JSONB,
--   message                   TEXT,
--   is_read                   BOOLEAN DEFAULT FALSE,
--   is_automated              BOOLEAN DEFAULT FALSE,
--   metadata                  JSONB,
--   created_at                TIMESTAMPTZ DEFAULT NOW()
-- );

-- Ejemplo de datos:
-- {
--   "id": "874d253e-bd3b-4523-a4ed-2b15dc96736d",
--   "booking_id": "7387be9a-c571-406b-b767-ec6e206540bc",
--   "sender_type": "guest",
--   "sender_name": "Sarah Johnson",
--   "sender_email": null,
--   "message": "Hi! I'd like to know if early check-in is possible for my reservation next week?",
--   "is_read": false,
--   "is_automated": false,
--   "metadata": null,
--   "created_at": "2025-11-12T10:50:00.355031+00:00"
-- }


-- ================================================
-- EXTENSIONS
-- ================================================

CREATE EXTENSION IF NOT EXISTS pg_net;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";


-- ================================================
-- FUNCTIONS
-- ================================================

-- Función: notify_property_registered
CREATE OR REPLACE FUNCTION notify_property_registered()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-created',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object(
      'id', NEW.id,
      'name', NEW.name,
      'location', NEW.location,
      'type', NEW.type,
      'beds', NEW.beds,
      'baths', NEW.baths,
      'base_price', NEW.base_price,
      'created_at', NEW.created_at
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ================================================
-- TRIGGERS
-- ================================================

-- Trigger: on_property_insert
DROP TRIGGER IF EXISTS on_property_insert ON properties;
CREATE TRIGGER on_property_insert
  AFTER INSERT ON properties
  FOR EACH ROW
  EXECUTE FUNCTION notify_property_registered();

