-- ================================================
-- ELIMINAR TODAS LAS POLICIES MANUALMENTE
-- ================================================
-- Ejecuta este archivo PRIMERO
-- Si alguna da error, ignóralo y continúa
-- ================================================

-- Properties policies
DROP POLICY IF EXISTS "Public properties are viewable by everyone" ON properties;
DROP POLICY IF EXISTS "Authenticated users can insert properties" ON properties;
DROP POLICY IF EXISTS "Users can update own properties" ON properties;
DROP POLICY IF EXISTS "Users can delete own properties" ON properties;

-- Bookings policies
DROP POLICY IF EXISTS "Authenticated users can view bookings" ON bookings;
DROP POLICY IF EXISTS "Authenticated users can insert bookings" ON bookings;
DROP POLICY IF EXISTS "Property owners can update bookings" ON bookings;

-- Payments policies
DROP POLICY IF EXISTS "Users can view own payments" ON payments;
DROP POLICY IF EXISTS "System can insert payments" ON payments;

-- Messages policies
DROP POLICY IF EXISTS "Users can view own messages" ON messages;
DROP POLICY IF EXISTS "Authenticated users can insert messages" ON messages;

SELECT 'Todas las policies eliminadas!' as status;
