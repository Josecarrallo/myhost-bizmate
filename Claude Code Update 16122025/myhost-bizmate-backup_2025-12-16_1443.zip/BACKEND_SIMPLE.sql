-- ================================================
-- MY HOST BizMate - BACKEND SIMPLIFICADO
-- ================================================
-- Solo las funciones esenciales que coinciden con tu BD
-- ================================================

-- EXTENSIONES NECESARIAS
CREATE EXTENSION IF NOT EXISTS pg_net;

-- ================================================
-- FUNCIÓN: Estadísticas del Dashboard
-- ================================================

CREATE OR REPLACE FUNCTION get_dashboard_stats()
RETURNS TABLE(
  total_properties BIGINT,
  total_bookings BIGINT,
  active_bookings BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM properties WHERE status = 'active'),
    (SELECT COUNT(*) FROM bookings),
    (SELECT COUNT(*) FROM bookings WHERE status IN ('confirmed', 'checked_in'));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ================================================
-- FUNCIÓN: Actualizar timestamp automáticamente
-- ================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ================================================
-- TRIGGERS para updated_at
-- ================================================

DROP TRIGGER IF EXISTS update_properties_updated_at ON properties;
CREATE TRIGGER update_properties_updated_at
  BEFORE UPDATE ON properties
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_bookings_updated_at ON bookings;
CREATE TRIGGER update_bookings_updated_at
  BEFORE UPDATE ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_payments_updated_at ON payments;
CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ================================================
-- GRANTS
-- ================================================

GRANT EXECUTE ON FUNCTION get_dashboard_stats() TO authenticated;

-- ================================================
-- VERIFICACIÓN
-- ================================================

SELECT 'Backend simplificado instalado correctamente!' as status;
