# 📦 Supabase Backups & Backend Scripts

Esta carpeta contiene todos los scripts SQL, backups y documentación del backend de MY HOST BizMate.

---

## 📁 Archivos Principales

### 🔥 **COMPLETE_BACKEND_FASE1.sql**
**El archivo más importante - Backend Fase 1 completo**

Contiene:
- ✅ 8 triggers automáticos (properties, bookings, payments, messages)
- ✅ 8 funciones SQL (5 webhooks + 3 estadísticas)
- ✅ 11 RLS Policies (seguridad completa)
- ✅ 15 índices de optimización
- ✅ Grants y permisos

**Tamaño:** ~500 líneas
**Estado:** ✅ Listo para ejecutar
**Instrucciones:** Ver `INSTRUCCIONES_BACKEND_FASE1.md`

---

### 📋 **INSTRUCCIONES_BACKEND_FASE1.md**
Guía paso a paso para aplicar el SQL en Supabase:
- Método 1: SQL Editor (recomendado)
- Método 2: psql CLI
- Verificación de instalación
- Troubleshooting común

---

### 📊 **BACKEND_FASE1_RESUMEN.md**
Documento ejecutivo con:
- Resumen de todo lo implementado
- Comparación antes/después
- Checklist post-instalación
- Roadmap de integración

---

## 📦 Backups Anteriores

### **SUPABASE_FULL_BACKUP_2025-11-27.sql**
Backup inicial de la estructura de base de datos:
- 5 tablas (properties, bookings, guests, payments, messages)
- 1 trigger (on_property_insert)
- 1 función (notify_property_registered)
- Ejemplos de datos

### **supabase_schema_2025-11-27.json**
Schema completo en formato JSON con:
- Estructura de columnas
- Tipos de datos
- Ejemplos de registros

### **supabase_backup_1764232153057.sql**
Primer backup con trigger básico de propiedades.

### **README_BACKUP.md**
Documentación del primer backup realizado.

---

## 🛠️ Scripts de Utilidad

### **extract-full-schema.js**
Script Node.js para extraer el schema completo de Supabase:
- Conecta con service_role key
- Extrae estructura de tablas
- Genera archivos SQL y JSON
- Incluye ejemplos de datos

**Uso:**
```bash
node extract-full-schema.js
```

⚠️ **Nota:** Contiene credenciales - No subir a git

---

## 🔐 Seguridad

Esta carpeta está protegida en `.gitignore` porque contiene:
- ❌ Service Role Keys de Supabase
- ❌ Backups con datos reales
- ❌ Scripts con credenciales

**NUNCA subas esta carpeta a GitHub.**

---

## 🚀 Cómo Usar

### Para aplicar Backend Fase 1:

1. **Abre Supabase Dashboard**
   ```
   https://supabase.com/dashboard
   ```

2. **Ve a SQL Editor**
   - Click en "SQL Editor" en el menú lateral
   - Click en "New query"

3. **Ejecuta el script**
   - Abre `COMPLETE_BACKEND_FASE1.sql`
   - Copia TODO el contenido
   - Pégalo en el editor
   - Click en **RUN**

4. **Verifica instalación**
   ```sql
   -- Ver funciones
   SELECT routine_name FROM information_schema.routines
   WHERE routine_schema = 'public';

   -- Ver triggers
   SELECT trigger_name FROM information_schema.triggers
   WHERE trigger_schema = 'public';
   ```

---

## 📚 Estructura del Backend

```
MY HOST BizMate Backend
│
├── Base de Datos (Supabase PostgreSQL)
│   ├── properties (20 columnas)
│   ├── bookings (15 columnas)
│   ├── guests (vacía)
│   ├── payments (13 columnas)
│   └── messages (10 columnas)
│
├── Triggers (8)
│   ├── on_property_insert → webhook n8n
│   ├── on_booking_insert → webhook n8n
│   ├── on_booking_status_update → webhook n8n
│   ├── on_payment_update → webhook n8n
│   ├── on_message_insert → webhook n8n
│   ├── update_properties_updated_at
│   ├── update_bookings_updated_at
│   └── update_payments_updated_at
│
├── Funciones Webhook (5)
│   ├── notify_property_registered()
│   ├── notify_booking_created()
│   ├── notify_booking_status_changed()
│   ├── notify_payment_confirmed()
│   └── notify_message_received()
│
├── Funciones Estadísticas (3)
│   ├── get_dashboard_stats()
│   ├── get_revenue_by_month(months)
│   └── get_top_properties(limit)
│
└── Seguridad
    ├── RLS Policies (11)
    ├── Índices (15)
    └── Grants
```

---

## 🔗 Webhooks N8N

Todos los triggers apuntan a:
```
https://n8n-production-bb2d.up.railway.app
```

### Endpoints requeridos:
1. `/webhook/property-created` ← properties INSERT
2. `/webhook/booking-created` ← bookings INSERT
3. `/webhook/booking-status-changed` ← bookings UPDATE
4. `/webhook/payment-confirmed` ← payments INSERT/UPDATE
5. `/webhook/message-received` ← messages INSERT

---

## ✅ Checklist

### Backend SQL
- [x] Estructura de BD definida
- [x] Triggers creados (8/8)
- [x] Funciones implementadas (8/8)
- [x] RLS Policies configuradas (11)
- [x] Índices optimizados (15)
- [ ] **SQL ejecutado en Supabase** ← PENDIENTE

### N8N Integration
- [ ] Webhook 1: property-created
- [ ] Webhook 2: booking-created
- [ ] Webhook 3: booking-status-changed
- [ ] Webhook 4: payment-confirmed
- [ ] Webhook 5: message-received

### Frontend Integration
- [ ] Función get_dashboard_stats() en Dashboard
- [ ] Función get_revenue_by_month() en Reports
- [ ] Función get_top_properties() en Properties

---

## 📞 Soporte

**Proyecto:** MY HOST BizMate
**URL Base de Datos:** https://jjpscimtxrudtepzwhag.supabase.co
**Documentación Supabase:** https://supabase.com/docs

---

**Generado por:** Claude Code
**Última actualización:** 2025-11-27
