-- EXTENSIÓN pg_net
CREATE EXTENSION IF NOT EXISTS pg_net;

-- FUNCIÓN PARA WEBHOOK
CREATE OR REPLACE FUNCTION notify_property_registered()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-created',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object(
      'id', NEW.id,
      'name', NEW.name,
      'location', NEW.location,
      'type', NEW.type,
      'beds', NEW.beds,
      'baths', NEW.baths,
      'base_price', NEW.base_price,
      'created_at', NEW.created_at
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- TRIGGER
DROP TRIGGER IF EXISTS on_property_insert ON properties;

CREATE TRIGGER on_property_insert
  AFTER INSERT ON properties
  FOR EACH ROW
  EXECUTE FUNCTION notify_property_registered();