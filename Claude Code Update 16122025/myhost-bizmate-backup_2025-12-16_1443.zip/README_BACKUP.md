# Supabase Database Backup - MY HOST BizMate

**Fecha:** 2025-11-27
**Proyecto:** jjpscimtxrudtepzwhag
**URL:** https://jjpscimtxrudtepzwhag.supabase.co

## Archivos Generados

### 1. SUPABASE_FULL_BACKUP_2025-11-27.sql
Script SQL completo con:
- Estructura de 5 tablas (CREATE TABLE con tipos de datos)
- Triggers y funciones
- Extensions necesarias (pg_net, uuid-ossp)
- Ejemplos de datos reales

### 2. supabase_schema_2025-11-27.json
Schema completo en formato JSON con estructura de columnas y tipos de datos.

### 3. supabase_backup_1764232153057.sql
Backup inicial con triggers.

## Tablas Extraídas

### 1. **properties** (20 columnas)
Gestión de propiedades vacacionales
- id, user_id, name, location, type
- description, beds, baths, max_guests
- base_price, currency, images, amenities
- status, rating, address, city, country
- created_at, updated_at

**Trigger activo:** `on_property_insert` → notifica a n8n cuando se inserta una propiedad

### 2. **bookings** (15 columnas)
Sistema de reservas
- id, property_id, guest_name, guest_email, guest_phone
- check_in, check_out, guests_count, total_amount
- status, booking_source, special_requests
- confirmation_code, created_at, updated_at

### 3. **guests** (tabla vacía)
Gestión de huéspedes (sin datos actuales)

### 4. **payments** (13 columnas)
Sistema de pagos
- id, booking_id, amount, currency, status
- payment_method, stripe_payment_id, stripe_payment_intent_id
- paid_at, refunded_at, notes
- created_at, updated_at

### 5. **messages** (10 columnas)
Sistema de mensajería
- id, booking_id, sender_type, sender_name, sender_email
- message, is_read, is_automated, metadata
- created_at

## Funciones SQL

### notify_property_registered()
Función trigger que envía webhook a n8n cuando se registra una nueva propiedad.

**URL Webhook:** https://n8n-production-bb2d.up.railway.app/webhook/booking-created

**Datos enviados:**
- id, name, location, type
- beds, baths, base_price
- created_at

## Extensions Instaladas

- `pg_net` - Para webhooks HTTP
- `uuid-ossp` - Para generación de UUIDs

## Cómo Restaurar

### Opción 1: Supabase Dashboard
1. Ve a SQL Editor en tu proyecto Supabase
2. Copia el contenido de `SUPABASE_FULL_BACKUP_2025-11-27.sql`
3. Ejecuta el script (ajusta según necesites)

### Opción 2: psql CLI
```bash
psql -h db.jjpscimtxrudtepzwhag.supabase.co -U postgres -d postgres -f SUPABASE_FULL_BACKUP_2025-11-27.sql
```

## Scripts de Extracción

### extract-full-schema.js
Script Node.js que se conecta a Supabase y extrae:
- Lista de tablas
- Estructura de columnas
- Tipos de datos (inferidos)
- Ejemplos de datos
- Genera archivos SQL y JSON

**Uso:**
```bash
node extract-full-schema.js
```

## Credenciales (NO SUBIR A GIT)

**IMPORTANTE:** Este directorio está en `.gitignore` para proteger:
- Service Role Key (en scripts)
- Datos sensibles de la base de datos
- Backups con información real

## Integración n8n

El proyecto usa n8n para automatizaciones:
- **URL n8n:** https://n8n-production-bb2d.up.railway.app
- **Webhook propiedades:** /webhook/booking-created

Ver carpeta `n8n_Supabase/` para workflows completos.

## Próximos Pasos

1. ✅ Backup del esquema completado
2. ⏳ Verificar RLS policies (Row Level Security)
3. ⏳ Documentar triggers adicionales para bookings
4. ⏳ Configurar backup automático periódico
5. ⏳ Integrar webhooks para bookings y payments

---

**Generado por:** Claude Code
**Proyecto:** MY HOST BizMate
