export { default } from './SmartPricing';
