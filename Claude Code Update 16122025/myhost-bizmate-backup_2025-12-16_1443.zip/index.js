export { default } from './Properties';
