-- ================================================
-- BACKUP SUPABASE SCHEMA - MY HOST BizMate
-- Date: 2025-11-27T08:29:11.947Z
-- Project: jjpscimtxrudtepzwhag
-- ================================================

-- Table: properties
-- Columns detected:
--   - id
--   - user_id
--   - name
--   - location
--   - type
--   - description
--   - beds
--   - baths
--   - max_guests
--   - base_price
--   - currency
--   - images
--   - amenities
--   - status
--   - rating
--   - address
--   - city
--   - country
--   - created_at
--   - updated_at

-- Table: bookings
-- Columns detected:
--   - id
--   - property_id
--   - guest_name
--   - guest_email
--   - guest_phone
--   - check_in
--   - check_out
--   - guests_count
--   - total_amount
--   - status
--   - booking_source
--   - special_requests
--   - confirmation_code
--   - created_at
--   - updated_at

-- Table: payments
-- Columns detected:
--   - id
--   - booking_id
--   - amount
--   - currency
--   - status
--   - payment_method
--   - stripe_payment_id
--   - stripe_payment_intent_id
--   - paid_at
--   - refunded_at
--   - notes
--   - created_at
--   - updated_at

-- Table: messages
-- Columns detected:
--   - id
--   - booking_id
--   - sender_type
--   - sender_name
--   - sender_email
--   - message
--   - is_read
--   - is_automated
--   - metadata
--   - created_at


-- ================================================
-- TRIGGERS Y FUNCIONES
-- ================================================

-- Extension requerida
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Función para notificación de propiedades
CREATE OR REPLACE FUNCTION notify_property_registered()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://n8n-production-bb2d.up.railway.app/webhook/booking-created',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := jsonb_build_object(
      'id', NEW.id,
      'name', NEW.name,
      'location', NEW.location,
      'type', NEW.type,
      'beds', NEW.beds,
      'baths', NEW.baths,
      'base_price', NEW.base_price,
      'created_at', NEW.created_at
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para propiedades
DROP TRIGGER IF EXISTS on_property_insert ON properties;
CREATE TRIGGER on_property_insert
  AFTER INSERT ON properties
  FOR EACH ROW
  EXECUTE FUNCTION notify_property_registered();

