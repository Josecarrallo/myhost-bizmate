$timestamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
$destination = "Claude Code Update/myhost-bizmate-backup_$timestamp.zip"
$sourcePath = "C:\myhost-bizmate"

Write-Host "Creando backup del proyecto..."
Write-Host "Destino: $destination"

# Crear archivo temporal con la lista de archivos a incluir
$tempFile = New-TemporaryFile
Get-ChildItem -Path $sourcePath -Recurse -File |
    Where-Object {
        $_.FullName -notmatch '\\node_modules\\' -and
        $_.FullName -notmatch '\\.git\\' -and
        $_.FullName -notmatch '\\dist\\' -and
        $_.FullName -notmatch '\\build\\' -and
        $_.FullName -notmatch '\\.vercel\\' -and
        $_.FullName -notmatch '\\Claude Code Update\\'
    } |
    Select-Object -ExpandProperty FullName |
    Out-File -FilePath $tempFile

# Crear el ZIP con los archivos filtrados
$files = Get-Content $tempFile
Write-Host "Comprimiendo $($files.Count) archivos..."

# Comprimir archivos
Compress-Archive -Path $files -DestinationPath "$sourcePath\$destination" -Force

# Limpiar archivo temporal
Remove-Item $tempFile

Write-Host "¡Backup completado exitosamente!"
Write-Host "Archivo: $destination"
